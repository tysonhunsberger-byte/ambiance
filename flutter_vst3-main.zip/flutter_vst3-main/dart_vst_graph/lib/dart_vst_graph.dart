/// Export the public graph API. Consumers should import this file to
/// access VstGraph without worrying about bindings.

export 'src/bindings.dart' show VstGraph;