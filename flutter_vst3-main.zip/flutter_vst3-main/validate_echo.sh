#!/bin/bash

# Build the validator
# cd vst3sdk
# cmake -B build_all .
# cd build_all
# make validator

# Run validator on echo plugin
vst3sdk/build_all/bin/Debug/validator vsts/echo/build/VST3/Release/echo.vst3