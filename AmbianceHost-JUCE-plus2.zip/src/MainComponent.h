
#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include "Session.h"
#include "Paths.h"
#include "GainProcessor.h"

class MainComponent : public juce::Component,
                      private juce::Button::Listener,
                      private juce::Slider::Listener,
                      private juce::ChangeListener {
public:
  MainComponent();
  ~MainComponent() override;
  void paint(juce::Graphics&) override;
  void resized() override;
private:
  // UI
  juce::TextButton scanButton{"Scan"}, addButton{"Add..."}, removeButton{"Remove"},
                   editorButton{"Open Editor"}, bankButton{"Switch Bank (A/B)"},
                   upButton{"Up"}, downButton{"Down"}, bypassButton{"Toggle Bypass"};
  juce::TextButton saveButton{"Save Session"}, loadButton{"Load Session"};
  juce::Slider mixSlider; // 0..100%
  juce::Label  mixLabel, latencyLabel;
  juce::ListBox chainList;

  // Audio + hosting
  juce::AudioDeviceManager deviceManager;
  juce::AudioPluginFormatManager formatManager;
  juce::KnownPluginList knownPlugins;
  std::unique_ptr<juce::AudioProcessorGraph> graph;
  std::unique_ptr<juce::AudioProcessorPlayer> player;

  // Nodes
  juce::AudioProcessorGraph::NodeID inputNodeID{1}, outputNodeID{2}, midiInputNodeID{3};
  GainProcessor* dryGainProc=nullptr; // owned by graph nodes
  GainProcessor* wetGainProc=nullptr;

  // Banks
  SessionState session; ChainState* activeChain=nullptr;

  // Async chooser must persist
  std::unique_ptr<juce::FileChooser> chooser;

  // Helpers
  void buttonClicked(juce::Button*) override;
  void sliderValueChanged(juce::Slider*) override;
  void changeListenerCallback(juce::ChangeBroadcaster*) override;
  void buildAudioGraph();
  void rebuildGraphFromSession();
  void refreshChainList();
  bool addPluginFromFile(const juce::File& f);
  void openSelectedEditor();
  void removeSelected();
  void moveSelected(int delta);
  void toggleBypass();
  void doScan();
  void saveSession();
  void loadSession();
  void updateMixGains();
  void updateLatencyLabel();
  static bool findDescriptionForFile(juce::AudioPluginFormatManager& fm, const juce::String& fileOrIdentifier, juce::PluginDescription& out);
  JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(MainComponent)
};
