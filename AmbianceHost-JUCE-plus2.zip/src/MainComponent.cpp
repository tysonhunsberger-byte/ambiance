
#include "MainComponent.h"
#include <algorithm>

bool MainComponent::findDescriptionForFile(juce::AudioPluginFormatManager& fm, const juce::String& fileOrIdentifier, juce::PluginDescription& out){
  juce::OwnedArray<juce::PluginDescription> types;
  for(int i=0;i<fm.getNumFormats();++i) fm.getFormat(i)->findAllTypesForFile(types, fileOrIdentifier);
  if(types.isEmpty()) return false; out=*types[0]; return true;
}

class PluginEditorWindow : public juce::DialogWindow{
public:
  PluginEditorWindow(const juce::PluginDescription& desc,
                     std::unique_ptr<juce::AudioPluginInstance> inst,
                     std::function<void(juce::MemoryBlock&)> onSave)
  : juce::DialogWindow(desc.name, juce::Colours::black, true), instance(std::move(inst)), saveCb(std::move(onSave)){
    setUsingNativeTitleBar(true); setResizable(true,true);
    if(auto* ed=instance->createEditorIfNeeded()){
      setContentOwned(ed,true);
      setResizable(true,true);
      centreWithSize(std::max(480, ed->getWidth()), std::max(320, ed->getHeight()));
      setVisible(true);
    } else {
      juce::AlertWindow::showMessageBoxAsync(juce::AlertWindow::InfoIcon,"No editor","This plug-in has no GUI."); delete this;
    }
  }
  void closeButtonPressed() override{
    juce::MemoryBlock mb; if(instance) instance->getStateInformation(mb); if(saveCb) saveCb(mb); delete this;
  }
private:
  std::unique_ptr<juce::AudioPluginInstance> instance; std::function<void(juce::MemoryBlock&)> saveCb;
};

MainComponent::MainComponent(){
  setSize(980,680);
  deviceManager.initialise(0,2,nullptr,true,{},nullptr);
  formatManager.addDefaultFormats();
  graph.reset(new juce::AudioProcessorGraph()); player.reset(new juce::AudioProcessorPlayer());
  player->setProcessor(graph.get()); deviceManager.addAudioCallback(player.get());
  session.activeBank="A"; activeChain=&session.bankA;

  addAndMakeVisible(scanButton); addAndMakeVisible(addButton); addAndMakeVisible(removeButton);
  addAndMakeVisible(upButton); addAndMakeVisible(downButton); addAndMakeVisible(bypassButton);
  addAndMakeVisible(editorButton); addAndMakeVisible(bankButton);
  addAndMakeVisible(saveButton); addAndMakeVisible(loadButton); addAndMakeVisible(chainList);
  addAndMakeVisible(mixSlider); addAndMakeVisible(mixLabel); addAndMakeVisible(latencyLabel);

  scanButton.addListener(this); addButton.addListener(this); removeButton.addListener(this);
  upButton.addListener(this); downButton.addListener(this); bypassButton.addListener(this);
  editorButton.addListener(this); bankButton.addListener(this);
  saveButton.addListener(this); loadButton.addListener(this);
  mixSlider.addListener(this);

  mixSlider.setRange(0.0, 100.0, 1.0);
  mixSlider.setValue(100.0);
  mixLabel.setText("Wet %", juce::dontSendNotification);
  latencyLabel.setText("Latency: 0 samples", juce::dontSendNotification);

  buildAudioGraph();
  refreshChainList();
}

MainComponent::~MainComponent(){ deviceManager.removeAudioCallback(player.get()); player.reset(); graph.reset(); }
void MainComponent::paint(juce::Graphics& g){ g.fillAll(juce::Colours::black); }
void MainComponent::resized(){
  auto r=getLocalBounds().reduced(8);
  auto top=r.removeFromTop(32);
  scanButton.setBounds(top.removeFromLeft(70));
  addButton.setBounds(top.removeFromLeft(70));
  removeButton.setBounds(top.removeFromLeft(80));
  upButton.setBounds(top.removeFromLeft(60));
  downButton.setBounds(top.removeFromLeft(70));
  bypassButton.setBounds(top.removeFromLeft(110));
  editorButton.setBounds(top.removeFromLeft(110));
  bankButton.setBounds(top.removeFromLeft(150));
  saveButton.setBounds(top.removeFromLeft(120));
  loadButton.setBounds(top.removeFromLeft(120));

  auto top2=r.removeFromTop(40);
  mixLabel.setBounds(top2.removeFromLeft(60));
  mixSlider.setBounds(top2.removeFromLeft(200));
  latencyLabel.setBounds(top2.removeFromLeft(300));

  r.removeFromTop(6);
  chainList.setBounds(r);
}

void MainComponent::buttonClicked(juce::Button* b){
  if(b==&scanButton) doScan();
  else if(b==&addButton){
    chooser = std::make_unique<juce::FileChooser>("Choose a plug-in", juce::File(),
    #if JUCE_MAC
      "*.vst3;*.vst;*.component"
    #elif JUCE_WINDOWS
      "*.vst3;*.vst;*.dll"
    #else
      "*.vst3;*.so"
    #endif
    );
    chooser->launchAsync(juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
      [this](const juce::FileChooser& fc){ auto f=fc.getResult(); if(f.existsAsFile()) addPluginFromFile(f); chooser.reset(); });
  } else if(b==&removeButton) removeSelected();
  else if(b==&upButton) moveSelected(-1);
  else if(b==&downButton) moveSelected(+1);
  else if(b==&bypassButton) toggleBypass();
  else if(b==&editorButton) openSelectedEditor();
  else if(b==&bankButton){ session.activeBank=(session.activeBank=="A"?"B":"A"); activeChain=(session.activeBank=="A"?&session.bankA:&session.bankB); rebuildGraphFromSession(); }
  else if(b==&saveButton) saveSession();
  else if(b==&loadButton) loadSession();
}

void MainComponent::sliderValueChanged(juce::Slider* s){
  if(s==&mixSlider){
    activeChain->wetMix = (float)(mixSlider.getValue()/100.0);
    updateMixGains();
  }
}
void MainComponent::changeListenerCallback(juce::ChangeBroadcaster*){}

void MainComponent::buildAudioGraph(){
  graph->clear();

  // IO
  auto in = graph->addNode(std::make_unique<juce::AudioProcessorGraph::AudioGraphIOProcessor>
        (juce::AudioProcessorGraph::AudioGraphIOProcessor::audioInputNode));
  auto out = graph->addNode(std::make_unique<juce::AudioProcessorGraph::AudioGraphIOProcessor>
        (juce::AudioProcessorGraph::AudioGraphIOProcessor::audioOutputNode));
  auto midiIn = graph->addNode(std::make_unique<juce::AudioProcessorGraph::AudioGraphIOProcessor>
        (juce::AudioProcessorGraph::AudioGraphIOProcessor::midiInputNode));
  inputNodeID=in->nodeID; outputNodeID=out->nodeID; midiInputNodeID=midiIn->nodeID;

  rebuildGraphFromSession();
}

void MainComponent::rebuildGraphFromSession(){
  // remove all nodes except IO
  juce::Array<juce::AudioProcessorGraph::Node::Ptr> toRemove;
  for(auto node : graph->getNodes())
      if(node->nodeID!=inputNodeID && node->nodeID!=outputNodeID && node->nodeID!=midiInputNodeID)
          toRemove.add(node);
  for(auto node : toRemove) graph->removeNode(node->nodeID);

  dryGainProc = nullptr; wetGainProc = nullptr;

  auto last=inputNodeID;
  int totalLatency = 0;

  // chain
  for (int idx=0; idx<activeChain->slots.size(); ++idx){
    auto& slot = activeChain->slots.getReference(idx);
    if (slot.bypassed) continue; // hard bypass by skipping

    juce::PluginDescription desc; if(!findDescriptionForFile(formatManager, slot.pluginID, desc)) continue;

    juce::String err;
    auto inst = std::unique_ptr<juce::AudioPluginInstance>(formatManager.createPluginInstance(desc, 44100.0, 512, err));
    if(!inst) continue;

    if(slot.state.getSize()>0) inst->setStateInformation(slot.state.getData(), (int)slot.state.getSize());

    auto node = graph->addNode(std::move(inst));

    // audio connections
    graph->addConnection({ {last, 0}, {node->nodeID, 0} });
    graph->addConnection({ {last, 1}, {node->nodeID, 1} });

    // midi to node (if it accepts midi it's ok; otherwise ignored)
    graph->addConnection({ {midiInputNodeID, juce::AudioProcessorGraph::midiChannelIndex},
                           {node->nodeID,     juce::AudioProcessorGraph::midiChannelIndex} });

    // accumulate latency
    if (auto* p = dynamic_cast<juce::AudioProcessor*>(node->getProcessor()))
        totalLatency += p->getLatencySamples();

    last = node->nodeID;
  }

  // Wet/Dry parallel mix
  // Wet path gain
  auto wetNode = graph->addNode(std::unique_ptr<juce::AudioProcessor>(new GainProcessor()));
  wetGainProc = dynamic_cast<GainProcessor*>(wetNode->getProcessor());
  if (wetGainProc) wetGainProc->setGain (activeChain->wetMix);

  graph->addConnection({ { last, 0 }, { wetNode->nodeID, 0 } });
  graph->addConnection({ { last, 1 }, { wetNode->nodeID, 1 } });
  graph->addConnection({ { wetNode->nodeID, 0 }, { outputNodeID, 0 } });
  graph->addConnection({ { wetNode->nodeID, 1 }, { outputNodeID, 1 } });

  // Dry path gain
  auto dryNode = graph->addNode(std::unique_ptr<juce::AudioProcessor>(new GainProcessor()));
  dryGainProc = dynamic_cast<GainProcessor*>(dryNode->getProcessor());
  if (dryGainProc) dryGainProc->setGain (1.0f - activeChain->wetMix);

  graph->addConnection({ { inputNodeID, 0 }, { dryNode->nodeID, 0 } });
  graph->addConnection({ { inputNodeID, 1 }, { dryNode->nodeID, 1 } });
  graph->addConnection({ { dryNode->nodeID, 0 }, { outputNodeID, 0 } });
  graph->addConnection({ { dryNode->nodeID, 1 }, { outputNodeID, 1 } });

  refreshChainList();
  updateMixGains();
  latencyLabel.setText("Latency: " + juce::String(totalLatency) + " samples", juce::dontSendNotification);
}

void MainComponent::refreshChainList(){
  class Model: public juce::ListBoxModel{
    ChainState& s;
  public:
    Model(ChainState& ss): s(ss) {}
    int getNumRows() override { return s.slots.size(); }
    void paintListBoxItem(int row, juce::Graphics& g, int w, int h, bool sel) override{
      g.fillAll(sel? juce::Colours::darkgrey: juce::Colours::transparentBlack);
      if(row>=0 && row<s.slots.size()){
        auto& slot=s.slots.getReference(row); g.setColour(juce::Colours::white);
        juce::String name = slot.pluginID + " [" + slot.format + "]";
        if (slot.bypassed) name << " (bypassed)";
        g.drawText(name, 8,0,w-16,h, juce::Justification::centredLeft);
      }
    }
  };
  chainList.setModel(new Model(*activeChain)); chainList.updateContent();
}

bool MainComponent::addPluginFromFile(const juce::File& f){
  juce::PluginDescription desc; if(!findDescriptionForFile(formatManager, f.getFullPathName(), desc)){
    juce::AlertWindow::showMessageBoxAsync(juce::AlertWindow::WarningIcon,"No plugin found", f.getFullPathName()); return false;
  }
  juce::String err; auto inst=std::unique_ptr<juce::AudioPluginInstance>(formatManager.createPluginInstance(desc,44100.0,512,err));
  if(!inst){ juce::AlertWindow::showMessageBoxAsync(juce::AlertWindow::WarningIcon,"Load failed", err); return false; }
  PluginSlotState slot; slot.pluginID=desc.fileOrIdentifier; slot.format=desc.pluginFormatName;
  inst->prepareToPlay(44100.0,512); inst->releaseResources(); inst->getStateInformation(slot.state);
  activeChain->slots.add(std::move(slot)); rebuildGraphFromSession(); return true;
}

void MainComponent::openSelectedEditor(){
  int row=chainList.getSelectedRow(); if(row<0 || row>=activeChain->slots.size()) return;
  auto slot=activeChain->slots[row]; juce::PluginDescription desc; if(!findDescriptionForFile(formatManager, slot.pluginID, desc)) return;
  juce::String err; auto inst=std::unique_ptr<juce::AudioPluginInstance>(formatManager.createPluginInstance(desc,44100.0,512,err)); if(!inst) return;
  if(slot.state.getSize()>0) inst->setStateInformation(slot.state.getData(), (int)slot.state.getSize());
  new PluginEditorWindow(desc, std::move(inst), [this,row](juce::MemoryBlock& mb){ auto& s=activeChain->slots.getReference(row); s.state=mb; rebuildGraphFromSession(); });
}

void MainComponent::removeSelected(){
  int row=chainList.getSelectedRow(); if(row<0 || row>=activeChain->slots.size()) return;
  activeChain->slots.remove(row); rebuildGraphFromSession();
}

void MainComponent::moveSelected(int delta){
  int row=chainList.getSelectedRow(); if(row<0) return;
  int newRow = juce::jlimit(0, activeChain->slots.size()-1, row + delta);
  if (newRow == row) return;
  activeChain->slots.move(row, newRow);
  rebuildGraphFromSession();
  chainList.selectRow(newRow);
}

void MainComponent::toggleBypass(){
  int row=chainList.getSelectedRow(); if(row<0 || row>=activeChain->slots.size()) return;
  auto& s = activeChain->slots.getReference(row);
  s.bypassed = !s.bypassed;
  rebuildGraphFromSession();
  chainList.selectRow(row);
}

void MainComponent::doScan(){
  juce::FileSearchPath sp; for(auto& p: DefaultPluginPaths::vst3()) sp.add(juce::File(p));
 #if JUCE_PLUGINHOST_VST
  for(auto& p: DefaultPluginPaths::vst2()) sp.add(juce::File(p));
 #endif
 #if JUCE_MAC && JUCE_PLUGINHOST_AU
  for(auto& p: DefaultPluginPaths::au()) sp.add(juce::File(p));
 #endif
  juce::AudioPluginFormat* format=nullptr;
  for(int i=0;i<formatManager.getNumFormats();++i) if(formatManager.getFormat(i)->getName().containsIgnoreCase("VST3")){ format=formatManager.getFormat(i); break; }
  if(!format && formatManager.getNumFormats()>0) format=formatManager.getFormat(0);
  if(!format){ juce::AlertWindow::showMessageBoxAsync(juce::AlertWindow::WarningIcon,"No formats","No plugin formats available."); return; }
  juce::PluginDirectoryScanner scanner(knownPlugins, *format, sp, true, {}, false);
  juce::String nm; while(scanner.scanNextFile(true,nm)) {}
  juce::AlertWindow::showMessageBoxAsync(juce::AlertWindow::InfoIcon,"Scan finished", juce::String(knownPlugins.getNumTypes()) + " plugins known.");
}

void MainComponent::saveSession(){
  chooser = std::make_unique<juce::FileChooser>("Save Ambiance session", juce::File(), "*.ambience.json");
  chooser->launchAsync(juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles,
    [this](const juce::FileChooser& fc){ auto f=fc.getResult(); if(f.getFileName().isNotEmpty()) SessionIO::saveToFile(f, session); chooser.reset(); });
}
void MainComponent::loadSession(){
  chooser = std::make_unique<juce::FileChooser>("Load Ambiance session", juce::File(), "*.ambience.json");
  chooser->launchAsync(juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
    [this](const juce::FileChooser& fc){ auto f=fc.getResult(); if(f.existsAsFile()){ SessionIO::loadFromFile(f, session); activeChain=(session.activeBank=="A"?&session.bankA:&session.bankB); rebuildGraphFromSession(); } chooser.reset(); });
}

void MainComponent::updateMixGains(){
  if(wetGainProc) wetGainProc->setGain(activeChain->wetMix);
  if(dryGainProc) dryGainProc->setGain(1.0f - activeChain->wetMix);
}

void MainComponent::updateLatencyLabel(){ /* already set in rebuildGraphFromSession */ }
