-- material list

modalys = modalys or {}

modalys.materials = {
  ["aluminium"]={
    ["density"]=2700,
    ["young"]=70000000000,
    ["poisson"]=0.35
  },
  ["bismuth"]={
    ["density"]=9780,
    ["young"]=32000000000,
    ["poisson"]=0.38
  },
  ["brass"]={
    ["density"]=8500,
    ["young"]=112500000000,
    ["poisson"]=0.33
  },
  ["bronze"]={
    ["density"]=8150,
    ["young"]=108000000000,
    ["poisson"]=0.34
  },
  ["cesium"]={
    ["density"]=1930,
    ["young"]=1700000000,
    ["poisson"]=0.3
  },
  ["copper"]={
    ["density"]=8940,
    ["young"]=119000000000,
    ["poisson"]=0.35
  },
  ["gold"]={
    ["density"]=19300,
    ["young"]=79000000000,
    ["poisson"]=0.43
  },
  ["iridium"]={
    ["density"]=22560,
    ["young"]=520000000000,
    ["poisson"]=0.26
  },
  ["iron"]={
    ["density"]=7870,
    ["young"]=200500000000,
    ["poisson"]=0.3
  },
  ["lead"]={
    ["density"]=11340,
    ["young"]=16000000000,
    ["poisson"]=0.43
  },
  ["lithium"]={
    ["density"]=534,
    ["young"]=4900000000,
    ["poisson"]=0.36
  },
  ["magnesium"]={
    ["density"]=1740,
    ["young"]=43000000000,
    ["poisson"]=0.29
  },
  ["mercury"]={
    ["density"]=13600,
    ["young"]=28500000000,
    ["poisson"]=0.5
  },
  ["nickel"]={
    ["density"]=8900,
    ["young"]=210000000000,
    ["poisson"]=0.3
  },
  ["osmium"]={
    ["density"]=22570,
    ["young"]=550000000000,
    ["poisson"]=0.25
  },
  ["platinum"]={
    ["density"]=21450,
    ["young"]=168000000000,
    ["poisson"]=0.39
  },
  ["silver"]={
    ["density"]=10500,
    ["young"]=83000000000,
    ["poisson"]=0.37
  },
  ["steel"]={
    ["density"]=7700,
    ["young"]=200000000000,
    ["poisson"]=0.31
  },
  ["tin"]={
    ["density"]=7310,
    ["young"]=47000000000,
    ["poisson"]=0.35
  },
  ["titanium"]={
    ["density"]=4540,
    ["young"]=120000000000,
    ["poisson"]=0.34
  },
  ["tungsten"]={
    ["density"]=19250,
    ["young"]=411000000000,
    ["poisson"]=0.28
  },
  ["zinc"]={
    ["density"]=7100,
    ["young"]=108000000000,
    ["poisson"]=0.25
  },
  ["arsenic"]={
    ["density"]=5700,
    ["young"]=8000000000,
    ["poisson"]=0.5
  },
  ["diamond"]={
    ["density"]=3500,
    ["young"]=1220000000000,
    ["poisson"]=0.2
  },
  ["granite"]={
    ["density"]=2700,
    ["young"]=40000000000,
    ["poisson"]=0.2
  },
  ["graphite"]={
    ["density"]=1825,
    ["young"]=255000000000,
    ["poisson"]=0.13
  },
  ["limestone"]={
    ["density"]=2700,
    ["young"]=35000000000,
    ["poisson"]=0.25
  },
  ["marble"]={
    ["density"]=2660,
    ["young"]=60000000000,
    ["poisson"]=0.16
  },
  ["quartz"]={
    ["density"]=2650,
    ["young"]=86500000000,
    ["poisson"]=0.17
  },
  ["sandstone"]={
    ["density"]=2000,
    ["young"]=10500000000,
    ["poisson"]=0.3
  },
  ["sapphire"]={
    ["density"]=3980,
    ["young"]=345000000000,
    ["poisson"]=0.26
  },
  ["shale"]={
    ["density"]=2500,
    ["young"]=35500000000,
    ["poisson"]=0.3
  },
  ["silicon"]={
    ["density"]=2330,
    ["young"]=159000000000,
    ["poisson"]=0.36
  },
  ["uranium"]={
    ["density"]=19100,
    ["young"]=208000000000,
    ["poisson"]=0.23
  },
  ["carbon fiber"]={
    ["density"]=1400,
    ["young"]=1095000000000,
    ["poisson"]=0.25
  },
  ["catgut"]={
    ["density"]=1300,
    ["young"]=6000000000,
    ["poisson"]=0.4
  },
  ["flax fiber"]={
    ["density"]=1450,
    ["young"]=60000000000,
    ["poisson"]=0.4
  },
  ["hemp fiber"]={
    ["density"]=1480,
    ["young"]=55000000000,
    ["poisson"]=0.4
  },
  ["horse hair"]={
    ["density"]=1300,
    ["young"]=5950000000,
    ["poisson"]=0.4
  },
  ["nylon"]={
    ["density"]=1175,
    ["young"]=5000000000,
    ["poisson"]=0.4
  },
  ["silkworm silk"]={
    ["density"]=1340,
    ["young"]=5500000000,
    ["poisson"]=0.4
  },
  ["spider silk"]={
    ["density"]=1300,
    ["young"]=3500000000,
    ["poisson"]=0.4
  },
  ["bone"]={
    ["density"]=1900,
    ["young"]=13500000000,
    ["poisson"]=0.15
  },
  ["carrot"]={
    ["density"]=1140,
    ["young"]=1360000,
    ["poisson"]=0.25
  },
  ["concrete"]={
    ["density"]=2340,
    ["young"]=40000000000,
    ["poisson"]=0.15
  },
  ["cork"]={
    ["density"]=225,
    ["young"]=20000000,
    ["poisson"]=0
  },
  ["glass (borosilicate)"]={
    ["density"]=2300,
    ["young"]=71500000000,
    ["poisson"]=0.2
  },
  ["glass (soda-lime)"]={
    ["density"]=2500,
    ["young"]=73000000000,
    ["poisson"]=0.23
  },
  ["ice"]={
    ["density"]=920,
    ["young"]=12000000000,
    ["poisson"]=0.35
  },
  ["marshmallow"]={
    ["density"]=370,
    ["young"]=29000,
    ["poisson"]=0
  },
  ["olive oil"]={
    ["density"]=920,
    ["young"]=1350000000,
    ["poisson"]=0.5
  },
  ["rubber (hard)"]={
    ["density"]=1150,
    ["young"]=1155000000,
    ["poisson"]=0.49
  },
  ["rubber (soft)"]={
    ["density"]=950,
    ["young"]=4000000,
    ["poisson"]=0.49
  },
  ["seawater"]={
    ["density"]=1020,
    ["young"]=2340000000,
    ["poisson"]=0.5
  },
  ["tooth enamel"]={
    ["density"]=2900,
    ["young"]=83000000000,
    ["poisson"]=0.28
  },
  ["water"]={
    ["density"]=1000,
    ["young"]=2150000000,
    ["poisson"]=0.5
  },
  ["ash"]={
    ["density"]=710,
    ["young"]=16000000000,
    ["poisson"]=0.35
  },
  ["balsa"]={
    ["density"]=160,
    ["young"]=6000000000,
    ["poisson"]=0.35
  },
  ["bamboo"]={
    ["density"]=350,
    ["young"]=14000000000,
    ["poisson"]=0.35
  },
  ["beech"]={
    ["density"]=700,
    ["young"]=14000000000,
    ["poisson"]=0.35
  },
  ["birch"]={
    ["density"]=670,
    ["young"]=16000000000,
    ["poisson"]=0.35
  },
  ["cocobolo"]={
    ["density"]=1070,
    ["young"]=13000000000,
    ["poisson"]=0.35
  },
  ["ebony"]={
    ["density"]=1010,
    ["young"]=18500000000,
    ["poisson"]=0.35
  },
  ["douglas fir"]={
    ["density"]=530,
    ["young"]=16000000000,
    ["poisson"]=0.35
  },
  ["larch"]={
    ["density"]=590,
    ["young"]=12000000000,
    ["poisson"]=0.35
  },
  ["mahogany"]={
    ["density"]=675,
    ["young"]=12000000000,
    ["poisson"]=0.35
  },
  ["african mahogany"]={
    ["density"]=545,
    ["young"]=12000000000,
    ["poisson"]=0.35
  },
  ["maple"]={
    ["density"]=800,
    ["young"]=17000000000,
    ["poisson"]=0.35
  },
  ["european maple"]={
    ["density"]=640,
    ["young"]=10000000000,
    ["poisson"]=0.35
  },
  ["oak"]={
    ["density"]=750,
    ["young"]=11000000000,
    ["poisson"]=0.35
  },
  ["african padouk"]={
    ["density"]=720,
    ["young"]=11770000000,
    ["poisson"]=0.35,
    ["freqloss"]=8.22e-06,
    ["constloss"]=6.22
  },
  ["pernambuco"]={
    ["density"]=985,
    ["young"]=21000000000,
    ["poisson"]=0.35
  },
  ["pine"]={
    ["density"]=425,
    ["young"]=9000000000,
    ["poisson"]=0.35
  },
  ["scots pine"]={
    ["density"]=510,
    ["young"]=16000000000,
    ["poisson"]=0.35
  },
  ["redwood"]={
    ["density"]=380,
    ["young"]=9500000000,
    ["poisson"]=0.35
  },
  ["rosewood"]={
    ["density"]=950,
    ["young"]=22150000000,
    ["poisson"]=0.35
  },
  ["pallisandre"]={
    ["density"]=840,
    ["young"]=16000000000,
    ["poisson"]=0.35,
    ["freqloss"]=4.7e-06,
    ["constloss"]=25.79
  },
  ["indian rosewood"]={
    ["density"]=735,
    ["young"]=12000000000,
    ["poisson"]=0.35
  },
  ["spruce"]={
    ["density"]=550,
    ["young"]=13000000000,
    ["poisson"]=0.35
  },
  ["canadian spruce"]={
    ["density"]=450,
    ["young"]=11000000000,
    ["poisson"]=0.35
  },
  ["norway spruce"]={
    ["density"]=460,
    ["young"]=15000000000,
    ["poisson"]=0.35
  },
  ["sitka spruce"]={
    ["density"]=465,
    ["young"]=13000000000,
    ["poisson"]=0.35
  },
  ["teak"]={
    ["density"]=815,
    ["young"]=13000000000,
    ["poisson"]=0.35
  },
  ["walnut"]={
    ["density"]=560,
    ["young"]=11000000000,
    ["poisson"]=0.35
  }
}

modalys.material = modalys.materials
materials = modalys.materials

_material_to_properties = function( p )
  local material = nil
  if p.material ~= nil then
    if type(p.material) == "string" then
      material = modalys.materials[string.lower(p.material)]
    elseif type(p.material) == "table" then
      material = p.material
    end
  end
  if material ~= nil then
    if material.density ~= nil and p.density == nil then
      p.density = material.density
    end
    if material.young ~= nil and p.young == nil then
      p.young = material.young
    end
    if material.poisson ~= nil and p.poisson == nil then
      p.poisson = material.poisson
    end
    if material.freqloss ~= nil and p.freqloss == nil then
      p.freqloss = material.freqloss
    end
    if material.constloss ~= nil and p.constloss == nil then
      p.constloss = material.constloss
    end
  end
end
