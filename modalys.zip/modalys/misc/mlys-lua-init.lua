--require("materials")

inf = math.huge

local _private = {}

-- legacy alias to modalys namespace:
mlys = modalys
modalys.root = {}

local _errors = {}
_errors["expected-object"] = "An object was expected as parameter"
-- TODO: other errors

print = modalys.print

local _type = function( v )
  return type(v)
end

table.array = function(dim)
  local A = {}
  for i=1,dim do
    A[i] = 0
  end
  return A
end

function dump(o)
  if _isController(o) then
    local x = modalys.get_value(o)
    return _get_variable_name(o)..'='..dump(x)
  elseif type(o) == 'table' then
    local s = '{'
      local first = true
      for k,v in pairs(o) do
        if not first then
          s = s ..', '
        else
          first = false
        end
        if type(k) == 'number' then
          s = s..dump(v)
        else
          k = '"'..k..'"'
          s = s ..'['..k..'] = '..dump(v)
        end
      end
    return s .. '}'
  else
    return tostring(o)
  end
end

local _get_dimension = function( v )
  if v == nil then
    return 0
  end
  local dim = 1
  if _isController(v) then
    dim = modalys.get_info("dimension",v)
  else
    if _type(v) == "table" then
      dim = #v
    elseif _type(v) == "nil" then
      dim = 0
    end
  end
  return dim
end

local _harmonize_parameters = function( p )
  if p.dimension ~= nil then
    p.dim = p.dimension
  end
  if p.frequency ~= nil then
    p.freq = p.frequency
  elseif p.freqs ~= nil then
    p.freq = p.freqs
  elseif p.frequencies ~= nil then
    p.freq = p.frequencies
  end
  if p.times ~= nil then
    p.time = p.times
  elseif p.timing ~= nil then
    p.time = p.timing
  end
  if p.amps ~= nil then
    p.amp = p.amps
  elseif p.amplitude ~= nil then
    p.amp = p.amplitude
  elseif p.amplitudes ~= nil then
    p.amp = p.amplitudes
  end
  if p.bws ~= nil then
    p.bw = p.bws
  elseif p.bandwidth ~= nil then
    p.bw = p.bandwidth
  elseif p.bandwidths ~= nil then
    p.bw = p.bandwidths
  end
  if p.inputs ~= nil then
    p.input = p.inputs
  elseif p.objects ~= nil then
    p.input = p.objects
  end
  if p.ctrls ~= nil then
    p.input = p.ctrls
  end
  if p.coefficient ~= nil then
    p.coeff = p.coefficient
  end
  if p.phases ~= nil then
    p.phase = p.phases
  end
  if p.accesses ~= nil then
    p.access = p.accesses
  end
  if p.controller ~= nil then
    p.ctrl = p.controller
  elseif p.ctl ~= nil then
    p.ctrl = p.ctl
  elseif p.ctlr ~= nil then
    p.ctrl = p.ctlr
  end
  if p.type ~= nil and p.kind == nil then
    p.kind = p.type
  end
  if p.values ~= nil then
    p.value = p.values
  end
  if p.kind ~= nil then
    p.kind = string.lower(p.kind)
    p.kind = string.gsub(p.kind, "normaliz", "normalis")
  end

  for k,v in pairs(p) do
    local newk = string.lower(k)
    newk = string.gsub(newk, "-", "")
    newk = string.gsub(newk, "_", "")
    if newk ~= k then
      p[newk] = v
      p[k] = nil
    end
  end
end

local _get_pitch_parameter = function(kind)
  local param = ""
  if kind == "rect-plate" then param = "size"
  elseif kind == "free-circ-plate" then param = "radius"
  elseif kind == "clamped-circ-plate" then param = "radius"
  elseif kind == "bi-string" then param = "length"
  elseif kind == "bi-two-mass" then param = "mass"
  elseif kind == "clamped-circ-plate" then param = "radius"
  elseif kind == "harmonic-oscillator" then param = "mass"
  elseif kind == "mono-string" then param = "length"
  elseif kind == "mono-two-mass" then param = "mass"
  elseif kind == "closed-closed-tube" then param = "length"
  elseif kind == "open-open-tube" then param = "length"
  elseif kind == "closed-open-tube" then param = "length"
  elseif kind == "cylindrical-tube" then param = "length"
  elseif kind == "cylindrical-fractional-delay-tube" then param = "length"
  elseif kind == "rect-free-bar" then param = "length"
  elseif kind == "circ-membrane" then param = "radius"
  elseif kind == "rect-membrane" then param = "size" end
  return param
end

local _make_controller_from_value = function( v, name, default, dim, constant )
  local c = 0
  if _isController(v) then
    c = v
  else
    if v == nil and default ~= nil then
      if dim ~= nil and dim > 1 and type(default) == "number" then
        v = {}
        for i=1,dim do
          v[i] = default
        end
      else
        v = default
      end
    end
    if v ~= nil then
      if constant ~= nil then
        c = _make_controller("CONSTANT", _get_dimension(v), v)
      else
        c = _make_controller("DYNAMIC", _get_dimension(v), -1, v, name)
      end
    end
  end
  return c
end

modalys.root.make_controller_from_value = _make_controller_from_value

local _make_weight_controller = function( v, name )
  local c = 0
  if _isController(v) then
    c = v
  else
    local w = 1
    if v ~= nil then
      w = v
    end
    c = _make_controller("DYNAMIC", 1, -1, w, name.."@weight")
  end
  return c
end

modalys.post_thru_modalys_tilde = function(...)
  local args = arg
  if args == nil then args = {...} end
  table.insert(args,1,_this_name())
  table.insert(args,1,"mlys.lua")
  _post_thru_modalys_tilde(args)
end
post_thru_modalys_tilde = modalys.post_thru_modalys_tilde

modalys.midi_to_freq = function( midi )
  return 440*math.pow(2,(midi-69)/12)
end

midi_to_freq = modalys.midi_to_freq

modalys.freq_to_midi = function( freq )
  return 12/math.log(2.)*math.log(freq/440.) + 69
end

freq_to_midi = modalys.freq_to_midi

modalys.normalised_random = function()
  return math.random()
end

math.Pow=function(x,y)
  if x>0 then return math.pow(x,y) end
  return math.pow(-x,y)
end

local warning = function(s)
  modalys.print("! mlys.lua - "..s)
end

local _uniqueNames = {}

local function _uniqueName(s)
  if _uniqueNames[s] ~= nil then
    local a,b = string.find(s, "%d+")
    if a ~= nil and b == s:len() then
      local n = tonumber(s:sub(a))
      n = n+1
      s = s:sub(1,a-1)..tostring(n)
    else
      s = s.."1"
    end
    s = _uniqueName(s)
  end
  _uniqueNames[s] = true
  return s
end

_showWarning = true

local function uniqueName(name, default)
  if name == default == nil then
    return nil
  end
  if name == nil then
    name = default
  end
  local c = name
  name = _uniqueName(name)
  if c ~= name and _showWarning then
    warning("the object name \'"..c.."\'' has been changed to \'"..name.."\' to avoid duplicate.")
  end
  return name
end

function releaseUniqueName(s)
  --TODO
end

modalys.view_mesh = function( x )
  if x == nil then print("nil value passed to \""..debug.getinfo(1, "n").name.."\"! :-(") return end
  if type(x) == "table" then
    return modalys.view(x)
  end
  if modalys.get_info("class-name",x) ~= "Mesh" then
    print("Mesh object parameter expected in \"modalys.view_mesh\" :-(")
  end
  _view("mesh",x)
end
-- alias:
view_mesh = modalys.view_mesh

modalys.view_object = function( o )
  if o == nil then print("nil value passed to \""..debug.getinfo(1, "n").name.."\"! :-(") return end
  _view("object",o)
end
-- alias:
view_object = modalys.view_object

modalys.view = function( x )
if x == nil then print("nil value passed to \""..debug.getinfo(1, "n").name.."\"! :-(") return end
  if type(x) == "table" then
    if x.mesh ~= nil then
      return _view(x.mesh)
    elseif x.object ~= nil then
      if x.mode ~= nil then
        if x.frames == nil then x.frames = 50 end
        if x.amp == nil then x.amp = 0. end
          --if x.length == nil then x.length = 1 end
          return _view("mode",x.object,x.mode,x.frames,1,x.amp)
        end
        return _view("object")
      end
    elseif type(x) == "number" then
      if modalys.get_info("class-name",x) == "Mesh" then
        return _view("mesh",x)
    end
    _view("object",x)
  end
end
-- alias:
view = modalys.view

modalys.create_access = function( p )
  _harmonize_parameters(p)
  if p.where ~= nil then p.object = p.where end
  if p.object == nil then return nil end
  p.name = uniqueName(p.name, "Access")
  local acc = nil
  if p.kind == "hybrid" and p.access ~= nil then
    local params = {}
    params[1]=p.object
    local dim = _get_dimension(p.access)
    for i=1,dim do
      params[i+1] = p.access[i]
    end
    params[dim+2] = "hybrid"
    acc = _make_access(unpack(params))
  else
    local loc = p.location
    if loc == nil then loc = p.position end
    if loc == nil then
      loc = 1
    end
    local kind = nil
    if p.kind ~= nil then kind = p.kind end
    if kind == nil then
      local numAccesses = modalys.get_info("num-accesses",p.object)
      local evenAccesses = (numAccesses%2 ~= 0)
      local objectClass = modalys.get_info("class-name",p.object)
      --modalys.print("object class: "..objectClass)
      if objectClass=="HarmonicOscillator"
           or objectClass=="Radiator"
           or string.find(objectClass,"Point") ~= nil
           or string.find(objectClass,"Bar") ~= nil
           or objectClass=="FiniteElement"
           or string.find(objectClass,"Plate") ~= nil
           or string.find(objectClass,"Membrane") ~= nil then
        kind="normal"
      elseif string.find(objectClass,"Bridge") ~= nil then
        kind="base"
      elseif string.find(objectClass,"Tube") ~= nil then
        kind="long"
      elseif evenAccesses or objectClass=="MonoTwoMass" or objectClass=="MonoString" or objectClass=="HangingChain" then
        kind="trans0"
      else
        kind="trans1"
      end
    end
    p.kind = kind
    local dim = _get_dimension(loc)
    local posCtrl = nil
    if not _isController(loc) then
      posCtrl = _make_controller("DYNAMIC", dim, -1, loc, p.name.."@position")
    else
      posCtrl = loc
    end
    acc = _make_access(p.object,posCtrl,kind)
  end
  if acc ~= nil then
    --_set_internal_variable_name(acc, p.name)
  else
    modalys.print("access \""..p.kind.."\" could not be created!")
  end
  return acc
end
-- alias:
modalys.make_access = modalys.create_access
create_access = modalys.create_access
make_access = modalys.create_access

modalys.create_hybrid_access = function( p )
  p.kind = "hybrid"
 return create_access(p)
end

create_hybrid_access = modalys.create_hybrid_access
create_access_hybrid = modalys.create_hybrid_access
make_hybrid_access = modalys.create_hybrid_access
make_access_hybrid = modalys.create_hybrid_access
modalys.make_hybrid_access = modalys.create_hybrid_access
modalys.make_access_hybrid = modalys.create_hybrid_access

modalys.create_point_input = function( p )
  _harmonize_parameters(p)
  p.name = uniqueName(p.name, "PointInput")
  local gainCtrl = _make_controller_from_value(p.gain, p.name.."@gain", 1)
  local channel = 0; if p.channel ~= nil then channel = p.channel-1 end
  return _make_point_input(channel,gainCtrl)
end
-- alias:
modalys.make_point_input = modalys.create_point_input
create_point_input = modalys.create_point_input
make_point_input = modalys.create_point_input


modalys.create_point_output = function( p )
  _harmonize_parameters(p)
  if p.where == nil then return nil end
  p.name = uniqueName(p.name, "PointOutput")
  -- 'p.where' is either an access, an object or a controller.
  -- 'p.modes' can be nil, a single integer value, or an array of integers
  local gainCtrl = _make_controller_from_value(p.gain, p.name.."@gain", 1)
  local channel = 0; if p.channel ~= nil then channel = p.channel-1 end
  if p.modes ~= nil then
    local dim = _get_dimension(p.modes)
    local modeCtrl = _make_controller("DYNAMIC", dim, -1, p.modes, p.name.."@modesselection")
    return _make_point_output(p.where,channel,gainCtrl,modeCtrl)
  elseif p.index ~= nil then
    return _make_point_output(p.where,channel,gainCtrl,p.index)
  end
  return _make_point_output(p.where,channel,gainCtrl)
end
-- alias:
modalys.make_point_output = modalys.create_point_output
create_point_output = modalys.create_point_output
make_point_output = modalys.create_point_output


modalys.create_input_force_signal_access = function( p )
  _harmonize_parameters(p)
  if p.where == nil or p.name == nil or (p.position == nil and p.location == nil) then return nil end
  p.name = uniqueName(p.name,"ForceSignalAccess")
  local pos = p.position
  if pos == nil then pos = p.location end
  local kind = "trans0"
  if p.kind ~= nil then kind = p.kind end
  local channel = 0; if p.channel ~= nil then channel = p.channel-1 end
  local gain = _make_controller_from_value(p.gain, p.name.."@gain", 1)
  local input = _make_point_input(channel, gain)
  local signal = _make_controller("SIGNAL", 1, input)
  local weight = _make_controller("DYNAMIC", 1, -1, 1, p.name.."@weight")
  local dim = _get_dimension( p.position)
  local posctrl = _make_controller_from_value(pos, p.name.."@position", 0.)
  local access = _make_access( p.where, posctrl, kind)
  local force = _make_connection("FORCE", access, signal, weight )
  return force
end
-- alias:
create_input_force_signal_access = modalys.create_input_force_signal_access


modalys.create_controller = function( p )
  _harmonize_parameters(p)
  local ctrl = nil
  local period = -1
  local value = {0}
  if p.kind ~= nil then
    p.kind = string.lower(p.kind)
    if p.value ~= nil then value = p.value end
    if p.period ~= nil then period = p.period end
  end
  if (p.kind == "dynamic" or p.kind == nil) then
    p.name = uniqueName(p.name, "Dynamic")
    local dim = 1
    if p.dim ~= nil and p.value == nil then
      dim = p.dim
      value = table.array(dim)
    else
      dim = _get_dimension(value)
    end
    ctrl = _make_controller("DYNAMIC",dim,period,value,p.name)

  elseif p.kind == "signal" and p.input ~= nil then
    local dim = _get_dimension(p.input)
    ctrl = _make_controller("SIGNAL",dim,p.input)

  elseif (p.kind == "access-speed" or p.kind == "access-position" or p.kind == "access-force") and p.access ~= nil then
    ctrl = _make_controller(string.upper(p.kind),1,p.access)

  elseif p.kind == "sine" and p.freq ~= nil then
    p.name = uniqueName(p.name,"SineController")
    local cfreqs = _make_controller_from_value(p.freq,p.name.."@frequency")
    local dim = _get_dimension(cfreqs)
    if p.phase == nil then p.phase = table.array(dim) end
    local cphases = _make_controller_from_value(p.phase,p.name.."@phase")
    if _get_dimension(cphases) ~= dim then
      modalys.print("error creating controller "..p.kind..": 'frequency' and 'phase' parameters must have the same dimension!")
      modalys.release(cphases,cfreqs)
    else
      ctrl = _make_controller("SINE",dim,cfreqs,cphases)
    end

elseif p.kind == "noise" then
    --{kind="noise",dimension=1,period=0,cutoff=8000,delmin=0.3,delmax=0.7,outmin=0,outmax=1,taps=30, name="MyNoise1"}
    if p.dim == nil then p.dim = 1 end
    if p.period == nil then p.period = 0 end
    local cutoff = _make_controller_from_value(p.cutoff, p.name.."@cutoff", 8000, p.dim)
    local delmin = _make_controller_from_value(p.delmin, p.name.."@delmin", 0.3, p.dim)
    local delmax = _make_controller_from_value(p.delmax, p.name.."@delmax", 0.7, p.dim)
    local outmin = _make_controller_from_value(p.outmin, p.name.."@outmin", 0, p.dim)
    local outmax = _make_controller_from_value(p.outmax, p.name.."@outmax", 1, p.dim)
    p.dim = _get_dimension(cutoff)
    local subctl = {cutoff,delmin,delmax,outmin,outmax}
    if p.taps == nil then p.taps = 10 end
    ctrl = _make_controller("NOISE",p.dim ,p.period,subctl,p.taps)

  elseif (p.kind == "bandlimited-noise" or p.kind == "band-limited-noise") then
    local dimension = p.dimension;
    if p.cutoff ~= nil then
      dimension = _get_dimension(p.cutoff)
    else
      if dimension == nil then
        dimension = 1
      end
    end
    if dimension ~= nil and dimension > 0 then
      local period = 0; if p.period ~= nil then period = p.period end
      local taps = 10; if p.taps ~= nil then taps = p.taps end
      local ccutoff = _make_controller_from_value(p.cutoff,p.name.."@cutoff",100,dimension)
      ctrl = _make_controller("BANDLIMITED-NOISE",dimension,period,ccutoff,taps)
    end

  elseif p.kind == "random" then
    if p.dim == nil then p.dim = 1 end
    if p.period == nil then p.period = 0.01 end
    ctrl = _make_controller("RANDOM",p.dim,p.period)

  elseif p.kind == "dimension" then
    if p.ctrl == nil then p.ctrl = p.input end
    if p.rank ~= nil then p.index = p.rank end
    if p.index == nil then p.index = 0 end
    ctrl = _make_controller("DIMENSION",-1, p.ctrl,p.index)

  elseif p.kind == "spread" and p.dim ~= nil  and p.ctrl ~= nil then
    if _isController(p.ctrl) then
      if p.period == nil then p.period = -1. end
      ctrl = _make_controller("SPREAD",p.dim,p.period,p.ctrl)
    end

  elseif p.kind == "sum" then
    if p.ctrl == nil then p.ctrl = p.input end
    if _isController(p.ctrl) then
      if p.period == nil then p.period = 0. end
      ctrl = _make_controller("SUM",1, p.period, p.ctrl)
    end

  elseif p.kind == "scale" then
    if p.ctrl == nil then p.ctrl = p.input end
    if _isController(p.ctrl) then
      local dim = _get_dimension(p.ctrl)
      if p.inmin == nil then p.inmin = 0. end
      if p.inmax == nil then p.inmax = 10. end
      if p.outmin == nil then p.outmin = 0. end
      if p.outmax == nil then p.outmax = 100. end
      ctrl = _make_controller("SCALE",dim, p.inmin, p.inmax, p.outmin, p.outmax, p.ctrl)
    end

  elseif p.kind == "last-sample" then
    ctrl = _make_controller("LAST-SAMPLE", -1)

  elseif p.kind == "phasor" and p.freq ~= nil then
    local dim = _get_dimension(p.freq)
    if p.phase == nil then
      if dim == 1 then
        p.phase = 0
      else
        p.phase = table.array(dim)
      end
    end
    ctrl = _make_controller("PHASOR",dim,p.freq,p.phase)

  elseif p.kind == "bilinear-filter" then
    --{kind="bilinear-filter",dimension=1,coefficients={a0,a1,b1},input=inputctrl, name="MyBilinearFilter"}
    if _isController(p.input) then
      local dim = _get_dimension(p.input)
      local ccoeffs = _make_controller_from_value(p.coefficients, p.name.."@coefficients", {0,0,0})
      if _get_dimension(ccoeffs) == 3 then
        ctrl = _make_controller("BILINEAR-FILTER",dim,ccoeffs,p.input)
      else
        modalys.print("error creating controller "..p.kind..": the dimension of 'coefficients' must be 3!")
        modalys.release(ccoeffs)
      end
    else
      modalys.print("error creating controller "..p.kind..": 'input' parameter must be a controller!")
    end

  elseif p.kind == "biquadratic-filter" then
    --{kind="biquadratic-filter",coefficients={a0,a1,a2,b1,b2},input=inputctrl,name="MyBiquadraticFilter"}
    if _isController(p.input) then
      local dim = _get_dimension(p.input)
      local ccoeffs = _make_controller_from_value(p.coefficients, p.name.."@coefficients", {0,0,0,0,0})
      if _get_dimension(ccoeffs) == 5 then
        ctrl = _make_controller("BIQUADRATIC-FILTER",dim,ccoeffs,p.input)
      else
        modalys.print("error creating controller "..p.kind..": the dimension of 'coefficients' must be 5!")
        modalys.release(ccoeffs)
      end
    else
      modalys.print("error creating controller "..p.kind..": 'input' parameter must be a controller!")
    end

  elseif p.kind == "constant-second-order-filter" then
    if _isController(p.input) then
      local dim = _get_dimension(p.input)
      if _get_dimension(p.amp) ~= dim or _get_dimension(p.freq) ~= dim or _get_dimension(p.bw) ~= dim then
        modalys.print("error creating controller "..p.kind..": the dimension of the input and the amps, frequencies and bandwidths should match!")
      else
        if _type(p.amp) == "number" then
          p.amp = {p.amp}
        end
        if _type(p.freq) == "number" then
          p.freq = {p.freq}
        end
        if _type(p.bw) == "number" then
          p.bw = {p.bw}
        end
        if p.period == nil then p.period = -1 end
        ctrl = _make_controller("CONSTANT-SECOND-ORDER-FILTER",dim,p.period,p.input,p.amp,p.freq,p.bw)
      end
    else
      modalys.print("error creating controller "..p.kind..": 'input' parameter must be a controller!")
    end

  elseif p.kind == "variable-second-order-filter" then
    if _isController(p.input) then
      local dim = _get_dimension(p.input)
      if dim ~= 1 or _get_dimension(p.freq) ~= dim or _get_dimension(p.bandwidth) ~= dim then
        modalys.print("error creating controller "..p.kind..": the dimension of the input must be 1!")
      else
        if p.period == nil then p.period = -1 end
        local cfreq = _make_controller_from_value(p.freq, p.name.."@freqs")
        local cbw = _make_controller_from_value(p.bw, p.name.."@bandwidths")
        ctrl = _make_controller("VARIABLE-SECOND-ORDER-FILTER",dim,p.period,p.input,p.amp,cfreq,cbw)
      end
    else
      modalys.print("error creating controller "..p.kind..": 'input' parameter must be a controller!")
    end

  elseif p.kind == "dimension-mapping" then
    --{kind="dimension-mapping",dimension=5, input={{ctrl1,indexCtrl1,indexOut1_1,indexOut1_2,...},{ctrl2,indexCtrl2,indexOut2_1,indexOut2_2,...},...},name="MyDimensionMapping"}
    local dim = p.dim
    local valid = true
    local args = {}
    args[1] = "DIMENSION-MAPPING"
    args[2] = dim
    local n = 3
    for k1,line in pairs(p.input) do
      if not _isController(line[1]) then
        modalys.print("error creating controller "..p.kind..": first value of each element of 'input' must be a controller!")
        valid = false
        break
      end
      args[n] = line
      n = n+1
    end
    if valid then
      ctrl = _make_controller(unpack(args))
    end

  elseif p.kind == "arithmetic" and p.operator ~= nil  and p.input ~= nil then
    if _type(p.input) == "table" then
      local dim = _get_dimension(p.input[1])
      ctrl = _make_controller("ARITHMETIC",dim,p.operator,p.input)
    end

  elseif p.kind == "constant" then
    local dim = _get_dimension(value)
    if p.dim ~= nil then dim = p.dim end
    ctrl = _make_controller("CONSTANT",dim,value)

  elseif p.kind == "moment" and p.tofollow ~= nil then
    if _isController(p.tofollow) then
      local cdelay = _make_controller_from_value(p.delay, p.name.."@delay", 0)
      local power = 1; if p.power ~= nil then power = p.power end
      if p.dim ~= nil then dim = p.dim end
      ctrl = _make_controller("MOMENT",cdelay,power,p.tofollow)
    end

  elseif p.kind == "delay" and p.input ~= nil then
    if _isController(p.input) then
      p.name = uniqueName(p.name,"DelayController")
      local cdelay = _make_controller_from_value(p.delay, p.name.."@delay", 0)
      local dim = _get_dimension(p.input)
      ctrl = _make_controller("DELAY",dim, cdelay,p.input)
    end

  elseif p.kind == "timer" then
    local ctime = _make_controller_from_value(p.time, p.name.."@time", 0)
    local cautoreload = _make_controller_from_value(p.autoreload, p.name.."@autoreload", 0)
    ctrl = _make_controller("TIMER",ctime,cautoreload)

  elseif p.kind == "connection-state" and _isConnection(p.connection) then
    ctrl = _make_controller("CONNECTION-STATE",1,p.connection)
  end

  if ctrl == nil then
    modalys.print("controller \""..p.kind.."\" could not be created!")
  elseif p.name ~= nil then
    --_set_internal_variable_name(ctrl, p.name)
    if p.issubcontroller ~= nil then
      _add_dependency_from_controller(ctrl)
    end
  end
  return ctrl
end
-- alias:
create_controller = modalys.create_controller
make_controller = modalys.create_controller
modalys.make_controller = modalys.create_controller

modalys.create_object = function( p )
  if p.kind == nil then
    modalys.print("create_object: the 'kind' parameter is required :-(")
    return nil
  end
  _harmonize_parameters(p)
  _material_to_properties(p)
  p.name = uniqueName(p.name, "MyObject")
  local o = nil
  if (p.kind == "from-file" or p.kind == "read-from-file") and p.path ~= nil then
    p.kind = "read-from-file"
    o = _make_object(p.name,string.upper(p.kind),p.path)
  elseif p.kind == "mono-string" or p.kind == "bi-string" then
    local c1 = _make_controller_from_value(p.modes, p.name.."@modes", 80)
    local c2 = _make_controller_from_value(p.length, p.name.."@length", 1.)
    local c3 = _make_controller_from_value(p.tension, p.name.."@tension", 94.66)
    local c4 = _make_controller_from_value(p.density, p.name.."@density", 1000)
    local c5 = _make_controller_from_value(p.radius, p.name.."@radius", 0.001)
    local c6 = _make_controller_from_value(p.young, p.name.."@young", 1.0e9)
    local c7 = _make_controller_from_value(p.freqloss, p.name.."@freqloss", 1.)
    local c8 = _make_controller_from_value(p.constloss, p.name.."@constloss", 1.)
    o = _make_object(p.name,string.upper(p.kind),c1,c2,c3,c4,c5,c6,c7,c8)

  elseif p.kind == "hanging-chain" then
    local c1 = _make_controller_from_value(p.modes, p.name.."@modes", 80)
    local c2 = _make_controller_from_value(p.length, p.name.."@length", 1.)
    local c3 = _make_controller_from_value(p.gravity, p.name.."@gravity", 9.81)
    local c4 = _make_controller_from_value(p.freqloss, p.name.."@freqloss", 1.)
    local c5 = _make_controller_from_value(p.constloss, p.name.."@constloss", 1.)
    o = _make_object(p.name,string.upper(p.kind),c1,c2,c3,c4,c5)

  elseif p.kind == "harmonic-oscillator" then
    local cm = _make_controller_from_value(p.mass, p.name.."@mass", 0.01)
    local cst = _make_controller_from_value(p.stiffness, p.name.."@stiffness", 15000)
    local cfl = _make_controller_from_value(p.freqloss, p.name.."@freqloss", 100)
    local ccl = _make_controller_from_value(p.constloss, p.name.."@constloss", 10)
    o = _make_object(p.name,string.upper(p.kind),cm,cst,cfl,ccl)

  elseif p.kind == "mono-two-mass" then
    local c1 = _make_controller_from_value(p.smallmass, p.name.."@smallmass", 0.01)
    local c2 = _make_controller_from_value(p.largemass, p.name.."@largemass", 0.01)
    local c3 = _make_controller_from_value(p.stiffness, p.name.."@stiffness", 15000)
    local c4 = _make_controller_from_value(p.freqloss, p.name.."@freqloss", 100)
    local c5 = _make_controller_from_value(p.constloss, p.name.."@constloss", 0)
    o = _make_object(p.name,string.upper(p.kind),c1,c2,c3,c4,c5)

  elseif p.kind == "bi-two-mass" then
    if p.stiffness0 ~= nil then
      p.stiffness2 = p.stiffness1;
      p.stiffness1 = p.stiffness0;
    end
    if p.freqloss0 ~= nil then
      p.freqloss2 = p.freqloss1;
      p.freqloss1 = p.freqloss0;
    end
    if p.constloss0 ~= nil then
      p.constloss2 = p.constloss1;
      p.constloss1 = p.constloss0;
    end
    local csm = _make_controller_from_value(p.smallmass, p.name.."@smallmass", 0.01)
    local clm = _make_controller_from_value(p.largemass, p.name.."@largemass", 0.01)
    local cst1 = _make_controller_from_value(p.stiffness1, p.name.."@stiffness1", 15000)
    local cst2 = _make_controller_from_value(p.stiffness2, p.name.."@stiffness2", 15000)
    local cfl1 = _make_controller_from_value(p.freqloss1, p.name.."@freqloss1", 100)
    local cfl2 = _make_controller_from_value(p.freqloss2, p.name.."@freqloss2", 100)
    local ccl1 = _make_controller_from_value(p.constloss1, p.name.."@constloss1", 0)
    local ccl2 = _make_controller_from_value(p.constloss2, p.name.."@constloss2", 0)
    o = _make_object(p.name,string.upper(p.kind),csm,clm,cst1,cst2,cfl1,cfl2,ccl1,ccl2)

  elseif p.kind == "cello-bridge" then
    local cm1 = _make_controller_from_value(p.centralmass, "", .0046, 1, true)
    local cm2 = _make_controller_from_value(p.uppermass, "", .0059, 1, true)
    local cm12 = _make_controller_from_value(p.feetmass, "", .0024, 1, true)
    local cdd = _make_controller_from_value(p.ddistance, "", .032, 1, true)
    local cd20 = _make_controller_from_value(p.d20distance, "", .01625, 1, true)
    local ch1d = _make_controller_from_value(p.hdistance, "", .052, 1, true)
    local cad = _make_controller_from_value(p.adistance, "", .035, 1, true)
    local ci20d = _make_controller_from_value(p.i20distance, "", .026, 1, true)
    local cd2s = _make_controller_from_value(p.d2stiffness, p.name.."@d2stiffness", 716.8)
    local cs1s = _make_controller_from_value(p.s1stiffness, p.name.."@s1stiffness", 360000)
    local cfl = _make_controller_from_value(p.freqloss, p.name.."@freqloss", 10)
    local ccl = _make_controller_from_value(p.constloss, p.name.."@constloss", 10)

    o = _make_object(p.name,string.upper(p.kind),cm1,cm2,cm12,cdd,cd20,ch1d,cad,ci20d,cd2s,cs1s,cfl,ccl)

  elseif p.kind == "violin-bridge" then
    local ccm = _make_controller_from_value(p.centralmass, "", .00177, 1, true)
    local cfm = _make_controller_from_value(p.feetmass, "", .00038, 1, true)
    local ced = _make_controller_from_value(p.edistance, "", .013, 1, true)
    local cad = _make_controller_from_value(p.adistance, "", .01625, 1, true)
    local chd = _make_controller_from_value(p.hdistance, "", .021, 1, true)
    local cbd = _make_controller_from_value(p.bdistance, "", .0065, 1, true)
    local cst = _make_controller_from_value(p.stiffness, p.name.."@stiffness", 1300000)
    local cfl = _make_controller_from_value(p.freqloss, p.name.."@freqloss", 10)
    local ccl = _make_controller_from_value(p.constloss, p.name.."@constloss", 10)
    o = _make_object(p.name,string.upper(p.kind),ccm,cfm,ced,cad,chd,cbd,cst,cfl,ccl)

  elseif p.kind == "circ-membrane" then
    local cm = _make_controller_from_value(p.modes, p.name.."@modes", 80)
    local cr = _make_controller_from_value(p.radius, p.name.."@radius", .5)
    local ct = _make_controller_from_value(p.tension, p.name.."@tension", 1000)
    local cd = _make_controller_from_value(p.density, p.name.."@density", .25)
    local cfl = _make_controller_from_value(p.freqloss, p.name.."@freqloss", 1)
    local ccl = _make_controller_from_value(p.constloss, p.name.."@constloss", 1)
    o = _make_object(p.name,string.upper(p.kind),cm,cr,ct,cd,cfl,ccl)

  elseif p.kind == "rect-membrane" then
    if p.length0 ~= nil then
      p.length2 = p.length1;
      p.length1 = p.length0;
    end
    local cm = _make_controller_from_value(p.modes, p.name.."@modes", 80)
    local cl1 = _make_controller_from_value(p.length1, p.name.."@length1", .5)
    local cl2 = _make_controller_from_value(p.length2, p.name.."@length2", .5)
    local ct = _make_controller_from_value(p.tension, p.name.."@tension", 1000)
    local cd = _make_controller_from_value(p.density, p.name.."@density", .1)
    local cfl = _make_controller_from_value(p.freqloss, p.name.."@freqloss", 1)
    local ccl = _make_controller_from_value(p.constloss, p.name.."@constloss", 1)
    o = _make_object(p.name,string.upper(p.kind),cm,cl1,cl2,ct,cd,cfl,ccl)

  elseif p.kind == "rect-free-bar" then
    if p.young2 ~= nil then
      p.young0 = p.young1;
      p.young1 = p.young2;
    end
    local cm = _make_controller_from_value(p.modes, p.name.."@modes", 80)
    local cl = _make_controller_from_value(p.length, p.name.."@length", 1)
    local cw = _make_controller_from_value(p.width, p.name.."@width", .05)
    local cth = _make_controller_from_value(p.thickness, p.name.."@thickness", .01)
    local cd = _make_controller_from_value(p.density, p.name.."@density", 1000)
    local cy0 = _make_controller_from_value(p.young0, p.name.."@young0", 1.2e10)
    local cy1 = _make_controller_from_value(p.young1, p.name.."@young1", 1.2e10)
    local cpois = _make_controller_from_value(p.poisson, p.name.."@poisson", 0.25)
    local cfl = _make_controller_from_value(p.freqloss, p.name.."@freqloss", 1)
    local ccl = _make_controller_from_value(p.constloss, p.name.."@constloss", 1)
    o = _make_object(p.name,string.upper(p.kind),cm,cl,cw,cth,cd,cy0,cy1,cpois,cfl,ccl)

  elseif p.kind == "rect-plate" then
    if p.length2 ~= nil then
      p.length0 = p.length1;
      p.length1 = p.length2;
    end
    local c1 = _make_controller_from_value(p.modes, p.name.."@modes", 80)
    local c2 = _make_controller_from_value(p.length0, p.name.."@length0", 0.5)
    local c3 = _make_controller_from_value(p.length1, p.name.."@length1", 0.5)
    local c4 = _make_controller_from_value(p.thickness, p.name.."@thickness", 0.01)
    local c5 = _make_controller_from_value(p.density, p.name.."@density", 7800)
    local c6 = _make_controller_from_value(p.young, p.name.."@young", 1.0e9)
    local c7 = _make_controller_from_value(p.poisson, p.name.."@poisson", 0.3)
    local c8 = _make_controller_from_value(p.freqloss, p.name.."@freqloss", 10)
    local c9 = _make_controller_from_value(p.constloss, p.name.."@constloss", 10)
    o = _make_object(p.name,string.upper(p.kind),c1,c2,c3,c4,c5,c6,c7,c8,c9)

  elseif p.kind == "clamped-circ-plate" then
    local cm = _make_controller_from_value(p.modes, p.name.."@modes", 80)
    local cr = _make_controller_from_value(p.radius, p.name.."@radius", .5)
    local cth = _make_controller_from_value(p.thickness, p.name.."@thickness", 0.01)
    local cd = _make_controller_from_value(p.density, p.name.."@density", 7800)
    local cy = _make_controller_from_value(p.young, p.name.."@young", 2e11)
    local cp = _make_controller_from_value(p.poisson, p.name.."@poisson", 0.3)
    local cfl = _make_controller_from_value(p.freqloss, p.name.."@freqloss", 1)
    local ccl = _make_controller_from_value(p.constloss, p.name.."@constloss", 1)
    o = _make_object(p.name,string.upper(p.kind),cm,cr,cth,cd,cy,cp,cfl,ccl)

  elseif p.kind == "free-circ-plate" then
    local cm = _make_controller_from_value(p.modes, p.name.."@modes", 80)
    local cr = _make_controller_from_value(p.radius, p.name.."@radius", 0.5)
    local cth = _make_controller_from_value(p.thickness, p.name.."@thickness", 0.01)
    local cd = _make_controller_from_value(p.density, p.name.."@density", 7800)
    local cy = _make_controller_from_value(p.young, p.name.."@young", 2e11)
    local cp = _make_controller_from_value(p.poisson, p.name.."@poisson", 0.3)
    local cfl = _make_controller_from_value(p.freqloss, p.name.."@freqloss", 1)
    local ccl = _make_controller_from_value(p.constloss, p.name.."@constloss", 1)
    o = _make_object(p.name,string.upper(p.kind),cm,cr,cth,cd,cy,cp,cfl,ccl)

  elseif p.kind == "open-open-tube" or p.kind == "closed-closed-tube" or p.kind == "closed-open-tube" then
    if p.radius0 ~= nil then
      p.radius2 = p.radius1;
      p.radius1 = p.radius0;
    end
    local cm = _make_controller_from_value(p.modes, p.name.."@modes", 80)
    local cl = _make_controller_from_value(p.length, p.name.."@length", 1)
    local cairel = _make_controller_from_value(p.airelasticity, p.name.."@airelasticity", .00000721)
    local cairdens = _make_controller_from_value(p.airdensity, p.name.."@airdensity", 1.2)
    local cr1 = _make_controller_from_value(p.radius1, p.name.."@radius1", .01)
    local cr2 = _make_controller_from_value(p.radius2, p.name.."@radius2", .01)
    local cfl = _make_controller_from_value(p.freqloss, p.name.."@freqloss", 1)
    local ccl = _make_controller_from_value(p.constloss, p.name.."@constloss", 1)
    o = _make_object(p.name,string.upper(p.kind),cm,cl,cairel,cairdens,cr1,cr2,cfl,ccl)

  elseif p.kind == "cylindrical-tube" then
    local cl = _make_controller_from_value(p.length, p.name.."@length", 1)
    local cr = _make_controller_from_value(p.radius, p.name.."@radius", .01)
    local crho = _make_controller_from_value(p.rho, p.name.."@rho", 1.2)
    local caircel = _make_controller_from_value(p.aircelerity, p.name.."@aircelerity", 340)
    local ccl = _make_controller_from_value(p.constloss, p.name.."@constloss", 1)
    o = _make_object(p.name,string.upper(p.kind),cl,cr,crho,caircel,ccl)

  elseif p.kind == "cylindrical-fractional-delay-tube" then
    local cl = _make_controller_from_value(p.length, p.name.."@length", 1)
    local cr = _make_controller_from_value(p.radius, p.name.."@radius", .01)
    local crho = _make_controller_from_value(p.rho, p.name.."@rho", 1.2)
    local caircel = _make_controller_from_value(p.aircelerity, p.name.."@aircelerity", 340)
    local ccl = _make_controller_from_value(p.constloss, p.name.."@constloss", 1)
    o = _make_object(p.name,string.upper(p.kind),cl,cr,crho,caircel,ccl)

  elseif p.kind == "radiator" then
    if p.density ~= nil then p.rho = p.density end
    local cr = _make_controller_from_value(p.radius, p.name.."@radius", .01)
    local cangle = _make_controller_from_value(p.angle, p.name.."@angle", 0)
    local crho = _make_controller_from_value(p.rho, p.name.."@rho", 1.2)
    local ccel = _make_controller_from_value(p.celerity, p.name.."@celerity", 340)
    o = _make_object(p.name,string.upper(p.kind),cr,cangle,crho,ccel)

  elseif p.kind == "finite-element" then
    if p.mesh == nil then
      warning("nil mesh with \"modalys.create_object\" and \"finite-element\"")
      return nil
    end 
    local cm = _make_controller_from_value(p.modes, p.name.."@modes", 80)
    local d = 7800; if p.density ~= nil then d = p.density end
    local th = 0.001; if p.thickness ~= nil then th = p.thickness end
    local y = 1.95e11; if p.young ~= nil then y = p.young end
    local poi = 0.2; if p.poisson ~= nil then poi = p.poisson end
    local cfl = _make_controller_from_value(p.freqloss, p.name.."@freqloss", 1)
    local ccl = _make_controller_from_value(p.constloss, p.name.."@constloss", 1)
    --TODO: p.material
    if p.block == nil then
      o = _make_object(p.name,string.upper(p.kind),cm,p.mesh,d,th,y,poi,cfl,ccl)
    else
      o = _make_object(p.name,string.upper(p.kind),cm,p.mesh,d,th,y,poi,cfl,ccl,p.block)
    end

    -- JET OBJECT
  elseif p.kind == "jet" then
    local cpr = _make_controller_from_value(p.pressure, p.name.."@pressure", 1.0)
    local cad = _make_controller_from_value(p.airdensity, "", 1.2, 1, true)
    local cas = _make_controller_from_value(p.airspeed, "", 340, 1, true)
    local cl = _make_controller_from_value(p.length, "", .03, 1, true)
    local cw = _make_controller_from_value(p.width, "", .02, 1, true)
    local ch = _make_controller_from_value(p.height, "", .001, 1, true)
    local cfld = _make_controller_from_value(p.fluelabiumdistance, p.name.."@fluelabiumdistance", .004)
    local clb = _make_controller_from_value(p.labiumposition, p.name.."@labiumposition", 2e-4)
    local cms = _make_controller_from_value(p.mouthsurface, p.name.."@mouthsurface", 8e-5)
    o = _make_object(p.name,string.upper(p.kind),cpr,cad,cas,cl,cw,ch,cfld,clb,cms)

    -- SINGLE-POINT OBJECT
  elseif p.kind == "single-point" then
    if p.freq == nil then p.freq = {440.} end
    if p.bw == nil then p.bw = {1.} end
    if p.amp == nil then p.amp = {1.} end
    local numModes = -1
    local cf = nil
    local cb = nil
    local ca = nil

    if _isController(p.freq) then
      numModes = modalys.get_info("dimension",p.freq)
      cf = p.freq
    else
      numModes = _get_dimension(p.freq)
      cf = _make_controller("DYNAMIC",numModes,-1,p.freq,p.name.."@freqs")
    end
    if _isController(p.bw) then
      cb = p.bw
    else
      cb = _make_controller("DYNAMIC",numModes,-1,p.bw,p.name.."@bws")
    end
    if _isController(p.amp) then
      ca = p.amp
    else
      ca = _make_controller("DYNAMIC",numModes,-1,p.amp,p.name.."@amps")
    end
    local cnumModes = _make_controller("CONSTANT",1,numModes)
    o = _make_object(p.name,string.upper(p.kind),cnumModes,cf,cb,ca)

    -- MULTIPLE-POINTS OBJECT
  elseif p.kind == "multiple-points" then
    --modalys.create_object{ kind="multiple-points",name="my-multiple",freqs={220, 440, 660, 880, 1100},bws={8., 4., 2., 1., 0.5}, amps={{1., 0.1}, {0.8, 0.08}, {0.7, 0.07}, {0.6, 0.06}, {0.5, 0.05}} }
    if p.freq ~= nil and p.bw ~= nil and (p.amp ~= nil or p.shapes ~= nil) then
      local numModes = -1
      local cf = nil
      if _isController(p.freq) then
        numModes = modalys.get_info("dimension",p.freq)
        cf = p.freq
      else
        numModes = _get_dimension(p.freq)
        cf = _make_controller("DYNAMIC",numModes,-1,p.freq,p.name.."@freqs")
      end
      local cb = nil
      if _isController(p.bw) then
        cb = p.bw
      else
        cb = _make_controller("DYNAMIC",numModes,-1,p.bw,p.name.."@bws")
      end
      local shapes = {}
      if p.shapes ~= nil then p.amp=p.shapes end
      if _type(p.amp) == "table" then
        for i,v in pairs(p.amp) do
          if _isController(v) then
            shapes[i]=v
          elseif _type(v) == "table" then
            local shape = _make_controller("DYNAMIC",_get_dimension(v),-1,v,p.name.."@shape_"..tostring(i))
            shapes[i]=shape
          end
        end
      else
        warning("the parameter \"amps\" or \"shapes\", which represents the modal shapes, must be a table of N values, N being the number of modes. Each value is either a table of P numbers (P=number of points) or a dynamic controller which dimension is P.")
        return nil
      end
      local cnumModes = _make_controller("CONSTANT",1,numModes)
      o = _make_object(p.name,string.upper(p.kind),cnumModes,cf,cb,shapes)
    end

  elseif p.kind == "clone" then
    if p.original == nil then
      warning("no reference to original object provided with \"modalys.create_object\" and \"clone\"")
      return nil
    end
    o = _make_object(p.name,string.upper(p.kind),p.original)
  elseif p.kind == "melt-hybrid" and p.input ~= nil then
    local dim = _get_dimension(p.input)
    local defaultInterp = table.array(dim)
    local cinterp = _make_controller_from_value(p.interpolation, p.name.."@interpolation", defaultInterp)
    local params = {}
    params[1] = p.name
    params[2] = p.kind
    params[3] = cinterp
    for i=1,dim do
      params[i+3] = p.input[i]
    end
    print(#p.." "..#(p.input).." "..#params)
    print(dump(params))
    o = _make_object(unpack(params))
  elseif p.kind == "mix-hybrid" and p.object1 ~= nil and p.object2 ~= nil then
    if _isObject(p.object1) and _isObject(p.object2) then
      local cinterp = _make_controller_from_value(p.interpolation, p.name.."@interpolation", 0)
      o = _make_object(p.name,string.upper(p.kind),p.object1,p.object2,cinterp)
    end 
  elseif p.kind == "tri-hybrid" and p.object1 ~= nil and p.object2 ~= nil and p.object3 ~= nil then
    if _isObject(p.object1) and _isObject(p.object2) and _isObject(p.object3) then
      local cinterp = _make_controller_from_value(p.interpolation, p.name.."@interpolation", {1,0,0})
      o = _make_object(p.name,string.upper(p.kind),p.object1,p.object2,p.object3,cinterp)
    end 
  end
  if o == nil then 
    warning(p.kind.." not implemented yet!")
  else
    if p.pitchparameter == nil then p.pitchparameter = _get_pitch_parameter(p.kind) end
    if p.pitchparameter ~= "" then
      local pctrl = _make_controller_from_value(p.pitch, p.name.."@pitch", 0.)
      _set_pitch(o, p.pitchparameter, pctrl)
    end
    modalys.compute_modes(o,p.async)
  end
  return o
end
-- alias:
modalys.make_object = modalys.create_object
create_object = modalys.create_object
make_object = modalys.create_object

modalys.save_object = function (p1, p2)
local obj = p1
local path = p2
if _type(p1) == "table" and p1.object ~= nil and p1.path ~= nil then
  obj = p1.object
  path = p1.path
end
_save_object(obj,path)
end
-- alias:
save_object = modalys.save_object


-- # # # # # # # # # #

modalys.create_connection = function( p )
  if p.kind == nil then return nil end
  _harmonize_parameters(p)
  p.name = uniqueName(p.name, "Connection")
  local cx = nil
  local supported = false
  local handled = false
  if p.kind == "force" then
    if p.where ~= nil then p.access = p.where end
    if not _isAccess(p.access) then
      modalys.print("error creating connection "..p.kind..": 'access' parameter must be a Modalys access!")
    else
      supported = true
      local ifce = 0; if p.initialforce ~= nil then ifce = p.initialforce end
      local drivingCtrl = p.input
      if drivingCtrl == nil then drivingCtrl = _make_controller("DYNAMIC",1,-1,ifce,p.name.."@force") end
      local cw = _make_weight_controller(p.weight,p.name)
      cx = _make_connection(string.upper(p.kind), p.access, drivingCtrl, cw)
    end

  elseif p.kind == "speed" then
    if p.where ~= nil then p.access = p.where end
    if not _isAccess(p.access) then
      modalys.print("error creating connection "..p.kind..": 'access' parameter must be a Modalys access!")
    else
      supported = true
      local sp = 0; if p.initialspeed ~= nil then sp = p.initialspeed end
      local drivingCtrl = p.input
      if drivingCtrl == nil then drivingCtrl = _make_controller("DYNAMIC",1,-1,sp,p.name.."@speed") end
      local cw = _make_weight_controller(p.weight,p.name)
      cx = _make_connection(string.upper(p.kind), p.access, drivingCtrl, cw)
    end

  elseif p.kind == "position" then
    if p.where ~= nil then p.access = p.where end
    if not _isAccess(p.access) then
      modalys.print("error creating connection "..p.kind..": 'access' parameter must be a Modalys access!")
    else
      supported = true
      local ip = 1 if p.initialposition ~= nil then ip = p.initialposition end
      local drivingCtrl = p.input
      if drivingCtrl == nil then drivingCtrl = _make_controller("DYNAMIC",1,-1,ip,p.name.."@position") end
      local cw = _make_weight_controller(p.weight,p.name)
      cx = _make_connection(string.upper(p.kind), p.access, drivingCtrl, cw )
        --TODO: bilateral position connection
      end

    elseif p.kind == "strike" then
      if p.where ~= nil then p.objectaccess = p.where end
      if p.where1 ~= nil then p.object1access = p.where1 end
      if p.where2 ~= nil then p.object2access = p.where2 end

      if p.object1access ~= nil  and p.object2access ~= nil then
        if not _isAccess(p.object1access) then
          modalys.print("error creating connection "..p.kind..": 'object1access' parameter must be a Modalys access!")
        elseif not _isAccess(p.object2access) then
          modalys.print("error creating connection "..p.kind..": 'object2access' parameter must be a Modalys access!")
        else
          supported = true
          local cw = _make_weight_controller(p.weight,p.name)
          local ip1 = 0 if p.object1initialposition ~= nil then ip1 = p.object1initialposition end
          local ip2 = 0 if p.object2initialposition ~= nil then ip2 = p.object2initialposition end
          cx = _make_connection(string.upper(p.kind), p.object1access, ip1, p.object2access, ip2, cw )
        end
      elseif p.objectaccess ~= nil then
      -- 'unilateral' strike:
      if not _isAccess(p.objectaccess) then
        modalys.print("error creating connection "..p.kind..": 'objectaccess' parameter must be a Modalys access!")
      else
        supported = true
        local cw = _make_weight_controller(p.weight,p.name)
        local ip = 0 if p.initialposition ~= nil then ip = p.initialposition end
        cx = _make_connection(string.upper(p.kind), p.objectaccess, ip, cw )
      end
    end

  elseif p.kind == "pluck" then
    if p.where1 ~= nil then p.plectrumaccess = p.where1 end
    if p.where2 ~= nil then p.objectaccess = p.where2 end
    if not _isAccess(p.plectrumaccess) then
      modalys.print("error creating connection "..p.kind..": 'plectrumaccess' parameter must be a Modalys access!")
    elseif not _isAccess(p.objectaccess) then
      modalys.print("error creating connection "..p.kind..": 'objectaccess' parameter must be a Modalys access!")
    else
      supported = true
      local cw = _make_weight_controller(p.weight,p.name)
      local cbf = _make_controller_from_value(p.breakingforce, p.name.."@breakingforce", 1)
      local ip1 = 0 if p.plectruminitialposition ~= nil then ip1 = p.plectruminitialposition end
      local ip2 = 0 if p.objectinitialposition ~= nil then ip2 = p.objectinitialposition end
      cx = _make_connection(string.upper(p.kind), p.plectrumaccess, ip1, p.objectaccess, ip2, cbf, cw )
    end

  elseif p.kind == "felt" then
    if p.where1 ~= nil then p.hammeraccess = p.where1 end
    if p.where2 ~= nil then p.objectaccess = p.where2 end
    if p.initialposition1 ~= nil then p.hammerinitialposition = p.initialposition1 end
    if p.initialposition2 ~= nil then p.objectinitialposition = p.initialposition2 end
    if not _isAccess(p.hammeraccess) then
      modalys.print("error creating connection "..p.kind..": 'hammeraccess' parameter must be a Modalys access!")
    elseif not _isAccess(p.objectaccess) then
      modalys.print("error creating connection "..p.kind..": 'objectaccess' parameter must be a Modalys access!")
    else
      supported = true
      local ip1 = 0 if p.hammerinitialposition ~= nil then ip1 = p.hammerinitialposition end
      local ip2 = 0.1 if p.objectinitialposition ~= nil then ip2 = p.objectinitialposition end
      local cth = _make_controller_from_value(p.thickness, p.name.."@thickness", 0.001)
      local cf0 = _make_controller_from_value(p.f0, p.name.."@f0", 1e9)
      local ca = _make_controller_from_value(p.alpha, p.name.."@alpha", 3)
      local ce = _make_controller_from_value(p.epsilon, p.name.."@epsilon", 0.5)
      local ct = _make_controller_from_value(p.tau, p.name.."@tau", 0.00001)
      local cw = _make_weight_controller(p.weight,p.name)
      cx = _make_connection(string.upper(p.kind),p.hammeraccess,ip1,p.objectaccess,ip2,cth,cf0,ca,ce,ct,cw)
    end

  elseif p.kind == "bow" then
    if not _isAccess(p.bowvaccess) then
      modalys.print("error creating connection "..p.kind..": 'bowvaccess' parameter must be a Modalys access!")
    elseif not _isAccess(p.bowhaccess) then
      modalys.print("error creating connection "..p.kind..": 'bowhaccess' parameter must be a Modalys access!")
    elseif not _isAccess(p.objectvaccess) then
      modalys.print("error creating connection "..p.kind..": 'objectvaccess' parameter must be a Modalys access!")
    elseif not _isAccess(p.objecthaccess) then
      modalys.print("error creating connection "..p.kind..": 'objecthaccess' parameter must be a Modalys access!")
    else
      if p.bowinitialvposition == nil then p.bowinitialvposition = 0.1 end
      if p.objectinitialvposition == nil then p.objectinitialvposition = 0 end
      local crosin = _make_controller_from_value(p.rosin, p.name.."@rosin", {2,10,5,4})
      local cw = _make_weight_controller(p.weight,p.name)
      cx = _make_connection(string.upper(p.kind),p.bowvaccess,p.bowhaccess,p.bowinitialvposition,p.objectvaccess,p.objecthaccess,p.objectinitialvposition,crosin,cw)
    end

  elseif p.kind == "adhere" then
    if p.where ~= nil then p.access = p.where elseif p.objectaccess ~= nil then p.access = p.objectaccess end
    if p.where1 ~= nil then p.access1 = p.where1 elseif p.object1access ~= nil then p.access1 = p.object1access end
    if p.where2 ~= nil then p.access2 = p.where2 elseif p.object2access ~= nil then p.access2 = p.object2access end
    if p.access ~= nil then
      supported = true
      local cw = _make_weight_controller(p.weight,p.name)
      cx = _make_connection(string.upper(p.kind), p.access, cw)
    elseif p.access1 ~= nil and p.access2 ~= nil then
      supported = true
      local cw = _make_weight_controller(p.weight,p.name)
      cx = _make_connection(string.upper(p.kind), p.access1, p.access2, cw)
    end

  elseif p.kind == "spring" and p.where1 ~= nil  and p.where2 ~= nil then
    supported = true
    local cst = _make_controller_from_value(p.stiffness, p.name.."@stiffness", 15000)
    local cfl = _make_controller_from_value(p.freqloss, p.name.."@freqloss", 10)
    local ccl = _make_controller_from_value(p.constloss, p.name.."@constloss", 10)
    local cw = _make_weight_controller(p.weight,p.name)
    cx = _make_connection(string.upper(p.kind), p.where1, p.where2,cst,cfl,ccl,cw)

  elseif p.kind == "hole" and p.radius ~= nil and p.noise ~= nil then
      -- retro-compatibility:
      if p.where ~= nil then p.access = p.where end
      if not _isAccess(p.access) then
        modalys.print("error creating connection "..p.kind..": 'access' parameter must be a Modalys access!")
      else
        local cw = _make_weight_controller(p.weight,p.name)
        local cradius = _make_controller_from_value(p.radius, p.name.."@radius")
        local cnoise = _make_controller_from_value(p.noise, p.name.."@noise")
        cx = _make_connection(string.upper(p.kind), p.access,cradius,cnoise,cw)
        supported = true
      end

  elseif p.kind == "viscous-damping" then
      if p.where ~= nil then p.access = p.where end
      if not _isAccess(p.access) then
        modalys.print("error creating connection "..p.kind..": 'access' parameter must be a Modalys access!")
      else
        local cw = _make_weight_controller(p.weight,p.name)
        local ccoeff = _make_controller_from_value(p.coeff, p.name.."@radius", 1)
        cx = _make_connection(string.upper(p.kind), p.access,ccoeff,cw)
        supported = true
      end

  elseif p.kind == "reed" then
    -- {kind="reed",reedaccess=m1acc1,tubeaccess=t3acc2,name="cxReed",initialposition=0.01, airpressure=2e4,airdensity=1.2,readarea=1e-8,aperturelength=2.76e-4,weight=0.7}
    -- retro-compatibility:
    if p.where1 ~= nil then p.reedaccess = p.where1 end
    if p.where2 ~= nil then p.tubeaccess = p.where2 end
    if not _isAccess(p.reedaccess) then
      modalys.print("error creating connection "..p.kind..": 'reedaccess' parameter must be a Modalys access!")
    elseif not _isAccess(p.tubeaccess) then
      modalys.print("error creating connection "..p.kind..": 'tubeaccess' parameter must be a Modalys access!")
    else
      supported = true
      local ip = 0 if p.initialposition ~= nil then ip = p.initialposition end
      local cpr = _make_controller_from_value(p.airpressure, p.name.."@airpressure", 2e4)
      local cad = _make_controller_from_value(p.airdensity, p.name.."@airdensity", 1.2)
      local ca = _make_controller_from_value(p.area, p.name.."@reedarea", 1e-8)
      local cal = _make_controller_from_value(p.aperturelength, p.name.."@aperturelength", 2.76e-4)
      local cw = _make_weight_controller(p.weight,p.name)
      cx = _make_connection(string.upper(p.kind),p.tubeaccess,p.reedaccess,ip,cpr,cad,ca,cal,cw)
    end

  elseif p.kind == "normalised-valve" then
    -- modalys.create_connection{kind="normalised-valve", name="MyNormalisedValve", valveaccess=acc1, initialposition=0.001, objectaccess=acc2,
    --                           breath=0, airdensity=1.2, zeta=0.7, frontangle=1e-8, aperturelength=0.01, weight=1}
    if p.objectaccess ~= nil then p.tubeaccess = p.objectaccess end
    if not _isAccess(p.valveaccess) then
      modalys.print("error creating connection "..p.kind..": 'valveaccess' parameter must be a Modalys access!")
    elseif not _isAccess(p.tubeaccess) then
      modalys.print("error creating connection "..p.kind..": 'tubeaccess' parameter must be a Modalys access!")
    else
      supported = true
      if p.aperturewidth ~= nil then p.aperturelength = p.aperturewidth end
      local ip = 0 if p.initialposition ~= nil then ip = p.initialposition end
      if p.gamma ~= nil then p.breath = p.gamma end
      local cb = _make_controller_from_value(p.breath, p.name.."@breath", 0)
      local cad = _make_controller_from_value(p.airdensity, p.name.."@airdensity", 1.2)
      local cz = _make_controller_from_value(p.zeta, p.name.."@zeta", 0.7)
      local cfa = _make_controller_from_value(p.frontangle, p.name.."@frontangle", 180)
      local cal = _make_controller_from_value(p.aperturelength, p.name.."@aperturelength", 0.01)
      local cw = _make_weight_controller(p.weight,p.name)
      cx = _make_connection(string.upper(p.kind), p.valveaccess,ip,p.tubeaccess,cb,cad,cz,cfa,cal,cw)
    end
  elseif p.kind == "mono-fingerboard" then
    if p.where1 ~= nil then p.fingeraccess = p.where1 end
    if p.where2 ~= nil then p.stringaccess = p.where2 end
    if not _isAccess(p.stringaccess) then
      modalys.print("error creating connection "..p.kind..": 'stringaccess' parameter must be a Modalys access!")
    elseif not _isAccess(p.fingeraccess) then
      modalys.print("error creating connection "..p.kind..": 'fingeraccess' parameter must be a Modalys access!")
    else
      supported = true
      if p.initialfingerposition == nil then p.initialfingerposition = 0.02 end
      if p.initialstringposition == nil then p.initialstringposition = 0.01 end
      if p.fingerboardposition == nil then p.fingerboardposition = 0. end

      local cw = _make_weight_controller(p.weight,p.name)
      cx = _make_connection(string.upper(p.kind),p.fingeraccess,p.initialfingerposition,p.stringaccess,p.initialstringposition,p.fingerboardposition,cw)
    end

  elseif p.kind == "bi-fingerboard" then
    if not _isAccess(p.fingervaccess) then
      modalys.print("error creating connection "..p.kind..": 'fingervaccess' parameter must be a Modalys access!")
    elseif not _isAccess(p.fingerhaccess) then
      modalys.print("error creating connection "..p.kind..": 'fingerhaccess' parameter must be a Modalys access!")
    elseif not _isAccess(p.stringvaccess) then
      modalys.print("error creating connection "..p.kind..": 'stringvaccess' parameter must be a Modalys access!")
    elseif not _isAccess(p.stringhaccess) then
      modalys.print("error creating connection "..p.kind..": 'stringhaccess' parameter must be a Modalys access!")
    else
      supported = true
      if p.initialfingerposition == nil then p.initialfingerposition = 0.02 end
      if p.initialstringposition == nil then p.initialstringposition = 0.01 end
      if p.fingerboardposition == nil then p.fingerboardposition = 0. end
      local cw = _make_weight_controller(p.weight,p.name)
      cx = _make_connection(string.upper(p.kind),p.fingervaccess,p.initialfingerposition,
                                                 p.stringvaccess,p.initialstringposition,
                                                 p.fingerboardposition,
                                                 p.fingerhaccess,
                                                 p.stringhaccess,
                                                 cw)
    end

  elseif p.kind == "valve" then
    if not _isAccess(p.objectaccess) then
      modalys.print("error creating connection "..p.kind..": 'objectaccess' parameter must be a Modalys access!")
    else
      if p.valveaccess ~=nil or ( p.valveaccess1 ~= nil and p.valveaccess2 == nil ) then  -- 1 access on valve
        if p.valveaccess1 ~= nil then
          p.valveaccess = p.valveaccess1
        end
        supported = true
        if p.aperturewidth ~= nil then p.aperturelength = p.aperturewidth end
        local ip = 0 if p.initialposition ~= nil then ip = p.initialposition end
        if p.gamma ~= nil then p.breath = p.gamma end
        local cb = _make_controller_from_value(p.breath, p.name.."@breath", 0)
        local cad = _make_controller_from_value(p.airdensity, p.name.."@airdensity", 1.2)
        local cuarea = _make_controller_from_value(p.underarea, p.name.."@underarea", 2e-5)
        local cfarea = _make_controller_from_value(p.frontarea, p.name.."@frontarea", 1e-4)
        local cfang = _make_controller_from_value(p.frontangle, p.name.."@frontangle", 180)
        local cal = _make_controller_from_value(p.aperturelength, p.name.."@aperturelength", 0.001)
        local cw = _make_weight_controller(p.weight,p.name)
        cx = _make_connection(string.upper(p.kind), p.valveaccess,ip,p.objectaccess,cb,cad,cuarea,cfarea,cfang,cal,cw)
      elseif p.valveaccess1 ~= nil and p.valveaccess2 ~= nil then  -- 2 accesses on valve
        supported = true
        if p.aperturewidth ~= nil then p.aperturelength = p.aperturewidth end
        local ip1 = 0 if p.initialposition1 ~= nil then ip1 = p.initialposition1 end
        local ip2 = 0 if p.initialposition2 ~= nil then ip2 = p.initialposition2 end
        if p.gamma ~= nil then p.breath = p.gamma end
        local cb = _make_controller_from_value(p.breath, p.name.."@breath", 0)
        local cad = _make_controller_from_value(p.airdensity, p.name.."@airdensity", 1.2)
        local cuarea = _make_controller_from_value(p.underarea, p.name.."@underarea", 2e-5)
        local cfarea = _make_controller_from_value(p.frontarea, p.name.."@frontarea", 1e-4)
        local cfang = _make_controller_from_value(p.frontangle, p.name.."@frontangle", 180)
        local cal = _make_controller_from_value(p.aperturelength, p.name.."@aperturelength", 0.001)
        local cw = _make_weight_controller(p.weight,p.name)
        cx = _make_connection(string.upper(p.kind), p.valveaccess1,ip1,p.valveaccess2,ip2,p.objectaccess,cb,cad,cuarea,cfarea,cfang,cal,cw)
      end
    end
  elseif p.kind == "leaky-valve" then
    if not _isAccess(p.objectaccess) then
      modalys.print("error creating connection "..p.kind..": 'objectaccess' parameter must be a Modalys access!")
    else
      if p.valveaccess ~=nil or ( p.valveaccess1 ~= nil and p.valveaccess2 == nil ) then  -- 1 access on valve
        if p.valveaccess1 ~= nil then
          p.valveaccess = p.valveaccess1
        end
        supported = true
        if p.aperturewidth ~= nil then p.aperturelength = p.aperturewidth end
        local ip = 0 if p.initialposition ~= nil then ip = p.initialposition end
        if p.gamma ~= nil then p.breath = p.gamma end
        local cb = _make_controller_from_value(p.breath, p.name.."@breath", 0)
        local cad = _make_controller_from_value(p.airdensity, p.name.."@airdensity", 1.2)
        local cav = _make_controller_from_value(p.airviscosity, p.name.."@airviscosity", 1.78e-5)
        local cuarea = _make_controller_from_value(p.underarea, p.name.."@underarea", 2e-5)
        local cfarea = _make_controller_from_value(p.frontarea, p.name.."@frontarea", 1e-4)
        local cfang = _make_controller_from_value(p.frontangle, p.name.."@frontangle", 180)
        local cal = _make_controller_from_value(p.aperturelength, p.name.."@aperturelength", 0.001)
        local ccl = _make_controller_from_value(p.canallength, p.name.."@canallength", 0.001)
        local cw = _make_weight_controller(p.weight,p.name)
        cx = _make_connection(string.upper(p.kind), p.valveaccess,ip,p.objectaccess,cb,cad,cav,cuarea,cfarea,cfang,cal,ccl,cw)
      elseif p.valveaccess1 ~= nil and p.valveaccess2 ~= nil then  -- 2 accesses on valve
        supported = true
        if p.aperturewidth ~= nil then p.aperturelength = p.aperturewidth end
        local ip1 = 0 if p.initialposition1 ~= nil then ip1 = p.initialposition1 end
        local ip2 = 0 if p.initialposition2 ~= nil then ip2 = p.initialposition2 end
        if p.gamma ~= nil then p.breath = p.gamma end
        local cb = _make_controller_from_value(p.breath, p.name.."@breath", 0)
        local cad = _make_controller_from_value(p.airdensity, p.name.."@airdensity", 1.2)
        local cav = _make_controller_from_value(p.airviscosity, p.name.."@airviscosity", 1.78e-5)
        local cuarea = _make_controller_from_value(p.underarea, p.name.."@underarea", 2e-5)
        local cfarea = _make_controller_from_value(p.frontarea, p.name.."@frontarea", 1e-4)
        local cfang = _make_controller_from_value(p.frontangle, p.name.."@frontangle", 180)
        local cal = _make_controller_from_value(p.aperturelength, p.name.."@aperturelength", 0.001)
        local ccl = _make_controller_from_value(p.canallength, p.name.."@canallength", 0.001)
        local cw = _make_weight_controller(p.weight,p.name)
        cx = _make_connection(string.upper(p.kind), p.valveaccess1,ip1,p.valveaccess2,ip2,p.objectaccess,cb,cad,cav,cuarea,cfarea,cfang,cal,ccl,cw)
      end
    end

  elseif p.kind == "normalised-leaky-valve" then
    --     modalys.create_connection{kind="normalised-leaky-valve", name="MyNormalisedLeakyValve", valveaccess=acc1, initialposition=0.001, objectaccess=acc2,
    --                               breath=0, airdensity=1.2, airviscosity=1.78e-5, zeta=0.7, frontangle=1e-8, aperturewidth=0.001, canallength=0.01, weight=1}
    if not _isAccess(p.valveaccess) then
      modalys.print("error creating connection "..p.kind..": 'valveaccess' parameter must be a Modalys access!")
    elseif not _isAccess(p.objectaccess) then
      modalys.print("error creating connection "..p.kind..": 'objectaccess' parameter must be a Modalys access!")
    else
      supported = true
      if p.aperturewidth ~= nil then p.aperturelength = p.aperturewidth end
      local ip = 0 if p.initialposition ~= nil then ip = p.initialposition end
      if p.gamma ~= nil then p.breath = p.gamma end
      local cb = _make_controller_from_value(p.breath, p.name.."@breath", 0)
      local cad = _make_controller_from_value(p.airdensity, p.name.."@airdensity", 1.2)
      local cav = _make_controller_from_value(p.airviscosity, p.name.."@airviscosity", 1.78e-5)
      local cz = _make_controller_from_value(p.zeta, p.name.."@zeta", 0.7)
      local cfa = _make_controller_from_value(p.frontangle, p.name.."@frontangle", 180)
      local caw = _make_controller_from_value(p.aperturelength, p.name.."@aperturelength", 0.001)
      local ccl = _make_controller_from_value(p.canallength, p.name.."@canallength", 0.001)
      local cuarea = _make_controller_from_value(p.underarea, p.name.."@underarea", 2e-5)
      local cw = _make_weight_controller(p.weight,p.name)
      cx = _make_connection(string.upper(p.kind), p.valveaccess,ip,p.objectaccess,cb,cad,cav,cz,cfa,caw,ccl,cuarea,cw)
    end
    elseif p.kind == "induction" then
      if p.where1 ~= nil then p.stringaccess = p.where1 end
      if p.where2 ~= nil then p.magnetaccess = p.where2 end
      if not _isAccess(p.stringaccess) then
        modalys.print("error creating connection "..p.kind..": 'stringaccess' parameter must be a Modalys access!")
      elseif not _isAccess(p.magnetaccess) then
        modalys.print("error creating connection "..p.kind..": 'magnetaccess' parameter must be a Modalys access!")
      elseif not _isController(p.signal) then
        modalys.print("error creating connection "..p.kind..": 'signal' parameter must be a Modalys controller!")
      else
        supported = true
        if p.magnetradius == nil then p.magnetradius = 0.01 end
        if p.length == nil then p.length = 0.02  end
        if p.permeability == nil then p.permeability = 8.737434e-4 end
        if p.stringradius == nil then p.stringradius = 0.0004 end

        local cgap = _make_controller_from_value(p.gap, p.name.."@gap", 0.001)
        local cw = _make_weight_controller(p.weight,p.name)
        cx = _make_connection(string.upper(p.kind),p.stringaccess,p.magnetaccess,p.signal,cgap,p.magnetradius,p.length,p.permeability,p.stringradius,cw)
      end

  elseif p.kind == "labium" then
    if p.access ~= nil then
      p.tubeaccess = p.access
    elseif p.objectaccess ~= nil then
      p.tubeaccess = p.objectaccess
    elseif p.where ~= nil then
      p.tubeaccess = p.where
    end
    if not _isAccess(p.tubeaccess) then
      modalys.print("error creating connection "..p.kind..": 'tubeaccess' parameter must be a Modalys access!")
    elseif not _isObject(p.jet) then
      modalys.print("error creating connection "..p.kind..": 'jet' parameter must be a jet Modalys object!")
    else
      supported = true
      local cnoise = _make_controller_from_value(p.noise, p.name.."@noise", 0.)
      local cvortex_f = _make_controller_from_value(p.vortexfactor, p.name.."@vortexfactor", {4.99, .1, 1})
      local cvortex_t = _make_controller_from_value(p.vortextransition, p.name.."@vortextransition", 0.005)
      local cw = _make_weight_controller(p.weight,p.name)
      cx = _make_connection(string.upper(p.kind), p.tubeaccess,p.jet,p.objectaccess,cnoise,cvortex_f,cvortex_t,cw)
    end
  end

  if cx == nil then
    if supported then 
      modalys.print("error creating connection "..p.kind.."!")
    --else
    --  modalys.print(p.kind.." not implemented in mlys.lua yet!")
    end
  --else
  --  _set_internal_variable_name(cx, p.name)
  end
  return cx
end
-- alias:
modalys.make_connection = modalys.create_connection
create_connection = modalys.create_connection
make_connection = modalys.create_connection

modalys.create_speed_connection = function(p)
  local acc = modalys.create_access(p)
  if acc ~= nil then
    p.where = acc
    p.kind="speed"
    local cx = modalys.create_connection(p)
    return cx
  end
  modalys.print("could not create access for speed connection!")
  return nil
end
-- alias:
create_speed_connection = modalys.create_speed_connection

-- # # # # # # # # # #

modalys.create_mesh = function( p )
  if p.kind == nil then return nil end
  _harmonize_parameters(p)
  local m = nil
  if (p.kind == "from-file" or p.kind == "read-from-file") and p.path ~= nil then
    p.kind = "read-from-file"
    m = _make_mesh(string.upper(p.kind), p.path, p.scale)
  elseif p.kind == "single-point" and p.position ~= nil then
    m = _make_mesh(string.upper(p.kind), p.position )
  elseif p.kind == "add" and _type(p.parts) == "table" then
    m = _make_mesh(string.upper(p.kind), p.parts )
  elseif p.kind == "copy" and p.mesh ~= nil then
    m = _make_mesh(string.upper(p.kind), p.mesh )
  elseif p.kind == "edge" and p.position1 ~= nil and p.position2 ~= nil then
    m = _make_mesh(string.upper(p.kind), p.position1, p.position2 )
  elseif p.kind == "quadrilateral" and p.vertices ~= nil then
    m = _make_mesh(string.upper(p.kind), p.vertices )
  elseif p.kind == "hexahedra" then
    --TODO
  elseif p.kind == "beam" then
    --TODO
  --elseif p.kind == "triangle" then
    --NOTTODO
  --elseif p.kind == "tetrahedron" then
    --NOTTODO
  elseif p.kind == "restrict-quadrilateral" and p.mesh ~= nil and p.nodes ~= nil then
    m = _make_mesh(string.upper(p.kind), p.mesh, p.nodes )
  elseif p.kind == "restrict-plane" and p.mesh ~= nil and p.normal ~= nil and p.point ~= nil then
    m = _make_mesh(string.upper(p.kind), p.mesh, p.normal, p.point )
  elseif p.kind == "restrict-line" and p.mesh ~= nil and p.vector ~= nil and p.point ~= nil then
    m = _make_mesh(string.upper(p.kind), p.mesh, p.vector, p.point )
  elseif p.kind == "restrict-point" or p.kind == "restrict-points" then
    p.kind = "restrict-point"
    m = _make_mesh(string.upper(p.kind), p.mesh, p.points )
  elseif p.kind == "restrict-edge" then
    --TODO
  end
  return m;
end
-- alias:
modalys.make_mesh = modalys.create_mesh
make_mesh = modalys.create_mesh
create_mesh = modalys.create_mesh

modalys.extend_mesh = function( p )
  if p.method == nil then return nil end
  _harmonize_parameters(p)
  local result = nil
  if p.method == "homothety" and p.mesh ~= nil then
    local steps = 1; if p.steps ~= nil then steps = p.steps end
    local center = {0,0,0}; if p.center ~= nil then center = p.center end
    local amplitude = 1; if p.amplitude ~= nil then amplitude = p.amplitude end
    result = _duplicate(p.method, p.mesh, steps, center, amplitude)
  elseif p.method == "reflection" and p.normal ~= nil and p.point ~= nil then
    result = _duplicate(p.method, p.mesh, p.normal, p.point)
  elseif (p.method == "rotation" or p.method == "helix") and p.mesh ~= nil and (p.angle ~= nil or p.stepangle ~= nil) then
    local steps = 1; if p.steps ~= nil then steps = p.steps end
    local axis = {0,0,0}; if p.axis ~= nil then axis = p.axis end
    local center = {0,0,0}; if p.center ~= nil then center = p.center end

    local angle = 0;
    if p.stepangle ~= nil then
      angle = p.stepangle
    else
      if p.angle > 30 then
        angle = p.angle/steps
      else
        angle = p.angle
      end
    end

    result = _duplicate(p.method, p.mesh, steps, axis, center, angle)
  elseif p.method == "translation" and p.mesh ~= nil and p.vector ~= nil then
    local steps = 1; if p.steps ~= nil then steps = p.steps end
    local vector = {0,0,0}; if p.vector ~= nil then vector = p.vector end
    result = _duplicate(p.method, p.mesh, steps, vector)
  end
  return result
end
-- alias:
modalys.duplicate_mesh = modalys.extend_mesh
duplicate_mesh = modalys.duplicate_mesh
extend_mesh = modalys.duplicate_mesh

modalys.transform_mesh = function( p )
  if p.method == nil then return nil end
  _harmonize_parameters(p)
  local result = nil
  if p.method == "homothety" and p.mesh ~= nil then
    local center = {0,0,0}; if p.center ~= nil then center = p.center end
    local scale = 1; if p.scale ~= nil then scale = p.scale end
    result = _transform(p.method, p.mesh, center, scale)
  elseif p.method == "reflection" and p.normal ~= nil and p.point ~= nil then
    result = _transform(p.method, p.mesh, p.normal, p.point)
  elseif (p.method == "rotation" or p.method == "helix") and p.mesh ~= nil and p.angle ~= nil then
    local axis = {0,0,0}; if p.axis ~= nil then axis = p.axis end
    local center = {0,0,0}; if p.center ~= nil then center = p.center end
    local angle = 90; if p.angle ~= nil then angle = p.angle end
    result = _transform(p.method, p.mesh, axis, center, angle)
  elseif p.method == "translation" and p.mesh ~= nil and p.vector ~= nil then
    local vector = {0,0,0}; if p.vector ~= nil then vector = p.vector end
    result = _transform(p.method, p.mesh, vector)
  end
  return result
end
-- alias:
transform_mesh = modalys.transform_mesh

modalys.save_mesh = function (p1,p2)
  local obj = p1
  local path = p2
  if _type(p1) == "table" and (p1.object ~= nil or p1.mesh ~= nil) and p1.path ~= nil then
    if p1.object ~= nil then
      obj = p1.object
    else
      obj = p1.mesh
    end
    path = p1.path
  end
  _save_mesh(obj,path)
end
-- alias:
save_mesh = modalys.save_mesh

modalys.get_mesh = function (obj)
  if obj == nil then return nil end
  return _get_mesh(obj)
end
-- alias:
get_mesh = modalys.get_mesh

modalys.get_node_coordinates = function( p1, p2, p3 )
  local obj = p1
  local node = p2
  local rank = p3
  if _type(p1) == "table" and p1.obj ~= nil then
    obj = p1.obj
  elseif _type(p1) == "table" and p1.object ~= nil then
    obj = p1.object
  end

  if _type(p1) == "table" and p1.node ~= nil then
    node = p1.node
    rank = p1.rank
  elseif _type(p1) == "table" and p1.index ~= nil then
    node = p1.index
    rank = p1.rank
  end
  if rank == nil then
    return _get_node_coordinate( obj, node )
  else
    return _get_node_coordinate( obj, node, rank )
  end
end
-- alias:
modalys.get_node_coordinate = modalys.get_node_coordinates
get_node_coordinates = modalys.get_node_coordinates
modalys.node_to_coordinate = modalys.get_node_coordinates
modalys.node_to_coordinates = modalys.get_node_coordinates
node_to_coordinates = modalys.get_node_coordinates

modalys.coordinates_to_node = function( p1, p2 )
  local obj = p1
  local coords = p2

  if _type(p1) == "table" and p1.obj ~= nil then
    obj = p1.obj
  elseif _type(p1) == "table" and p1.object ~= nil then
    obj = p1.object
  end

  if _type(p1) == "table" and p1.coords ~= nil then
    coords = p1.coords
  elseif _type(p1) == "table" and p1.coordinates ~= nil then
    coords = p1.coordinates
  elseif _type(p1) == "table" and p1.xyz ~= nil then
    coords = p1.xyz
  end
  return _coordinates_to_node( obj, coords )
end
-- alias:
coordinates_to_node = modalys.coordinates_to_node

modalys.freeze_object = function( ref, status )
  if ref ~= nil then
    if status == nil then status = true end
    _modalys_freeze_object(ref, status)
  end
end
-- alias:
freeze_object = modalys.freeze_object

modalys.release = function(...)
  local args = arg
  if args == nil then args = {...} end
  for _,ref in ipairs(args) do
    if _type(ref) == "number" then
      _destroy(ref)
    end
  end
end
-- alias:
release = modalys.release

modalys.add_controller_dependency = function(...)
  local args = arg
  if args == nil then args = {...} end
  for _,item in ipairs(args) do
    local ref = item
    if type(item) == "string" then
      ref = get_ref(item)
    end
    if _type(ref) == "number" and _isController(ref) then
      _add_dependency_from_controller(ref)
    end
  end
end
-- alias:
add_controller_dependency = modalys.add_controller_dependency

modalys.set_value = function(...)
  local args = arg
  if args == nil then args = {...} end
  local N = #args
  if N == 0 then
    -- TODO: error handling
    return
  end
  local p = {}
  if N == 1 and type(args[1]) == "table" then
    p = args[1]
    _harmonize_parameters(p)
  else
    p.ctrl = args[1]
    if N > 1 then
      p.value = args[2]
    end
    if N > 2 then
      if type(p.value) == "number" and math.round(args[3])==args[3] then
        p.rank = args[3]
      else
        p.time = args[3]
      end
    end
  end
  if _isController(p.ctrl) and p.value ~= nil then
    if p.time ~= nil and p.time > 0  then
      _setValueSmooth(p.ctrl,p.value,p.time)
    else
      if p.rank ~= nil then
        _setValue(p.ctrl,p.value,p.rank)
      else
        _setValue(p.ctrl,p.value)
      end
    end
  end
end

modalys.apply_envelope = function(...)
  local args = arg
  if args == nil then args = {...} end
  if #args == 0 then
        modalys.print("'apply_envelope' error: no parameter provided!")
    return
  end
  local p = {}
  if #args == 1 and type(args[1]) == "table" then
    p = args[1]
    _harmonize_parameters(p)
  else
    p.ctrl = args[1]
    p.value = args[2]
  end
  if type(p.ctrl) == "string" then
    local ref = get_ref(p.ctrl)
    if ref ~= nil then
      p.ctrl = ref
    end
  end
  if _isController(p.ctrl) then
    local dvalue = #p.value
    local dctrl = _get_dimension(p.ctrl)
    if p.time ~= nil then
      -- let us gather times and values: 
      local dtime = #p.time
      if dtime == dvalue/dctrl then
        for n=1,dtime do
          table.insert(p.value,(n-1)*dctrl+n,p.time[n])        end
      end
      local dvalue = #p.value
    end
  -- at this point p.value is expected to be a sequence of time/values: t1,v11,v12...v1n,...,tm,vi1,vi2,...vmn
  -- with n the controller's dimension and m the number of envelope points.
    _apply_envelope( p.ctrl, p.value )
  else
    modalys.print("'apply_envelope' error: controller parameter is wrong or absent!")
  end
end
apply_envelope = modalys.apply_envelope

modalys.set_amplitude_controller = function(o,c)
  local objref = get_ref(o)
  local ccref = get_ref(c)
  _set_amplitude_controller( objref, ccref )
end
set_amplitude_controller = modalys.set_amplitude_controller

modalys.set_frequency_controller = function(o,c)
  local objref = get_ref(o)
  local ccref = get_ref(c)
  _set_frequency_controller( objref, ccref )
end
set_frequency_controller = modalys.set_frequency_controller

modalys.set_loss_controller = function(o,c)
  local objref = get_ref(o)
  local ccref = get_ref(c)
  _set_loss_controller( objref, ccref )
end
set_loss_controller = modalys.set_loss_controller

modalys.get_os = function()
  return _get_os()
end
-- alias:
get_os = modalys.get_os

-- other aliases:
print=modalys.print
get_ref=modalys.get_ref
get_sample_rate=modalys.get_sample_rate
get_energy=modalys.get_energy
get_info=modalys.get_info
modalys.getinfo=modalys.get_info
getinfo=modalys.get_info
set_info=modalys.set_info
get_value=modalys.get_value
set_value=modalys.set_value
modalys.set_breakpoint=modalys.set_value
set_breakpoint=modalys.set_value
inlet=modalys.inlet
get_inlet_count=modalys.get_inlet_count
modalys.inlet_ref=modalys.get_inlet_ref
inlet_ref=modalys.inlet_ref
get_current_value=modalys.get_current_value
compute_modes=modalys.compute_modes
set_cents_pitchbend=modalys.set_cents_pitchbend
set_spectral_diffraction=modalys.set_spectral_diffraction

modalys.get_update_rate = _getUpdateRate
get_update_rate = _getUpdateRate
modalys.set_update_rate = _setUpdateRate
set_update_rate = _setUpdateRate
modalys.is_object_final = _isObjectFinal
is_object_final = _isObjectFinal

modalys.root.dump = dump
modalys.root.get_dimension = _get_dimension
modalys.root._this_name = _this_name
modalys.root._make_controller = _make_controller
modalys.root._make_object = _make_object
modalys.root._save_object = _save_object
modalys.root._make_mesh = _make_mesh
modalys.root._save_mesh = _save_mesh
modalys.root._get_node_coordinate = _get_node_coordinate
modalys.root._coordinates_to_node = _coordinates_to_node
modalys.root._duplicate = _duplicate
modalys.root._transform = _transform
modalys.root._make_access = _make_access
modalys.root._make_point_input = _make_point_input
modalys.root._destroy = _destroy
modalys.root._freeze_object = _freeze_object
modalys.root._set_pitch = _set_pitch
modalys.root._set_internal_variable_name = _set_internal_variable_name
modalys.root._get_variable_name = _get_variable_name
get_variable_name = _get_variable_name
modalys.root._post_message = _post_message
modalys.root._view = _view
modalys.root._get_OS = _getOS
modalys.root._is_rootObject = _isRootObject
modalys.root._is_controller = _isController
modalys.root._isAccess = _isAccess
modalys.root._isObject = _isObject
modalys.root._isConnexion = _isConnexion
modalys.root._isConnection = _isConnexion
_isConnection = _isConnexion
modalys.root._apply_envelope = _apply_envelope
