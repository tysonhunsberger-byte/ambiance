-- Modalys for Max mlys.lua tools
-- ##############################

function math.sign(v)
  return (v >= 0 and 1) or -1
end

function math.round(x, n)
  local y = 10^(n or 0)
  return math.floor(x * y + 0.5) / y
end

function math.Pow(x,y)
  if x>0 then return math.pow(x,y) end
  return math.pow(-x,y)
end

-- a few "classes":

-- ######
Average={v={},size=100,idx=0,factor=0.1,method="linear"}

function Average:new(o)
  o = o or {}
  setmetatable(o, self)
  self.__index = self
  for i=1,self.size do self.v[i]=0 end
  return o
end

function Average:update(e)
  if self.idx>self.size then self.idx=1 end
  if self.method =="linear" then
    self.v[self.idx] = e
  else
    self.v[self.idx] = e*e
  end
  local s = 0
  for i=1,self.size do s=s+self.v[i] end
  s = s/self.size
  if self.method ~="linear" then s = math.sqrt(s) end
  self.idx=self.idx+1
  s=s*self.factor
  return s
end

-- ######
InletChangeObserver={v={},size=0,callback=nil}

function InletChangeObserver:new(o)
  o = o or {}
  setmetatable(o, self)
  self.__index = self
  self.size = modalys.get_inlet_count()
  for i=1,self.size do self.v[i]=modalys.inlet(i) end
  return o
end

function InletChangeObserver:set_notification_function(f)
  self.callback = f
end

function InletChangeObserver:update()
  if self.callback == nil then return end
  for i=1,self.size do
    if modalys.inlet(i) ~= nil and self.v[i] ~= modalys.inlet(i) then
      self.callback(i,modalys.inlet(i))
    end 
    self.v[i]=modalys.inlet(i)
  end
end

modalys.inlet_observer = InletChangeObserver:new{callback=nil}
inlet_observer = modalys.inlet_observer

-- ######
ParametricCurve2D={f=nil,L=nil,v={},resolution=40,scale=1,min=0,max=1}
Parametriccurve=ParametricCurve2D

function ParametricCurve2D:new(o)
  o = o or {}
  setmetatable(o, self)
  self.__index = self
  return o
end

function ParametricCurve2D:discretize()
  self:length()
end

function ParametricCurve2D:length()
  if self.f == nil or self.L ~= nil then return L end
  self.L = 0
  local S = 1000
  local xBefore, yBefore
  local X={} local Y={} local Lp={}
  local i=0
  local dt = (self.max-self.min)/S
  for t=self.min,self.max,dt do
    local x,y=self:f_scaled(t)
    if t > 0 then
      self.L=self.L+math.sqrt((x-xBefore)^2+(y-yBefore)^2)
    end
    X[i]=x Y[i]=y Lp[i]=self.L
    xBefore,yBefore=x,y
    i=i+1
  end
  local dL = self.L/self.resolution
  self.v[0]=0
  local n = 1
  for i=0,S-1 do
    if Lp[i] >= n*dL then
      --self.v[n]=(i-1)/S+(1-(lp-n*dL)/(lp-Lp[i-1]))/S
      local g = (n*dL-Lp[i-1])/(Lp[i]-Lp[i-1])
      self.v[n] = self.min + dt*(i-1+g)
      n=n+1
    end
  end
  self.v[self.resolution]=1
  return self.L
end

function ParametricCurve2D:f_scaled(t)
  local x,y = self.f(t)
  return x*self.scale,y*self.scale
end

function ParametricCurve2D:getNodeXY(n)
  local x,y = self:f_scaled(self.v[n])
  return {math.round(x,4),math.round(y,4),0}
end

function ParametricCurve2D:getXmax()
  local m = 0
  for n=0,self.resolution do
    local x,y = self:f_scaled(self.v[n])
    x = math.round(x,4)
    if m < x then m = x end
  end
  return m
end

function ParametricCurve2D:getXmin()
  local m = 99999
  for n=0,self.resolution do
    local x,y = self:f_scaled(self.v[n])
    x = math.round(x,4)
    if m > x then m = x end
  end
  return m
end

function ParametricCurve2D:getYmax()
  local m = 0
  for n=0,self.resolution do
    local x,y = self:f_scaled(self.v[n])
    y = math.round(y,4)
    if m < y then m = y end
  end
  return m
end

function ParametricCurve2D:getYmin()
  local m = 99999
  for n=0,self.resolution do
    local x,y = self:f_scaled(self.v[n])
    y = math.round(y,4)
    if m > y then m = y end
  end
  return m
end

function ParametricCurve2D:createMeshFromCurve()
  self:discretize() 
  local M = modalys.create_mesh{ kind="edge", position1=self:getNodeXY(0), position2=self:getNodeXY(1)}
  for n=1,self.resolution-1 do
    local Mn = modalys.create_mesh{ kind="edge", position1=self:getNodeXY(n), position2=self:getNodeXY(n+1)}
    local Madd = modalys.create_mesh{ kind="add", parts={M,Mn} }
    modalys.release(M,Mn)
    M = Madd
  end
  return M
end

ParametricCurve2D.createMesh = ParametricCurve2D.createMeshFromCurve

-- ## --
ParametricCurve3D={f=nil,L=nil,v={},resolution=40,scale=1,min=0,max=1}

function ParametricCurve3D:new(o)
  o = o or {}
  setmetatable(o, self)
  self.__index = self
  return o
end

function ParametricCurve3D:discretize()
  self:length()
end

function ParametricCurve3D:length()
  if self.f == nil or self.L ~= nil then return L end
  self.L = 0
  local S = 1000
  local xBefore, yBefore, zBefore
  local X={} local Y={} local Z={} local Lp={}
  local i=0
  local dt = (self.max-self.min)/S
  for t=self.min,self.max,dt do
    local x,y,z=self:f_scaled(t)
    if t > self.min then
      self.L=self.L+math.sqrt((x-xBefore)^2+(y-yBefore)^2+(z-zBefore)^2)
    end
    X[i]=x Y[i]=y Z[i]=z
    Lp[i]=self.L
    xBefore,yBefore,zBefore=x,y,z
    i=i+1
  end
  local dL = self.L/self.resolution
  local lp = 0
  self.v[0]=self.min
  local n = 1
  for i=0,S-1 do
    local lp=Lp[i]
    if lp >= n*dL then
      local g = (n*dL-Lp[i-1])/(Lp[i]-Lp[i-1])
      self.v[n] = self.min + dt*(i-1+g)
      n=n+1
    end
  end
  self.v[self.resolution]=self.max
  return self.L
end

function ParametricCurve3D:f_scaled(t)
  local x,y,z = self.f(t)
  return x*self.scale,y*self.scale,z*self.scale
end

function ParametricCurve3D:getNodeXYZ(n)
  local x,y,z = self:f_scaled(self.v[n])
  return {math.round(x,4),math.round(y,4),math.round(z,4)}
end

function ParametricCurve3D:createMeshFromCurve()
  self:discretize() 
  local M = modalys.create_mesh{ kind="edge", position1=self:getNodeXYZ(0), position2=self:getNodeXYZ(1)}
  for n=1,self.resolution-1 do
    local Mn = modalys.create_mesh{ kind="edge", position1=self:getNodeXYZ(n), position2=self:getNodeXYZ(n+1)}
    local Madd = modalys.create_mesh{ kind="add", parts={M,Mn} }
    modalys.release(M,Mn)
    M = Madd
  end
  return M
end

ParametricCurve3D.createMesh = ParametricCurve3D.createMeshFromCurve

-- ## --
ParametricSurface3D={f=nil,xyz={},
                     resolution_s=20,resolution_t=20,
                     min_s=0,max_s=1,min_t=0,max_t=1,
                     loop_t="no",loop_s="no",scale=1}

function ParametricSurface3D:new(o)
  o = o or {}
  setmetatable(o, self)
  self.__index = self
  return o
end

function ParametricSurface3D:f_scaled(s,t)
  local x,y,z = self.f(s,t)
  return x*self.scale,y*self.scale,z*self.scale
end

function ParametricSurface3D:discretize()
  --zeroing ixj matrix:
  for i=0,self.resolution_s do
    self.xyz[i] = {}
  end
  local fiber_s = ParametricCurve3D:new{scale=self.scale, resolution=self.resolution_s, min=self.min_s, max=self.max_s,
                                          f=function(s) return self:f_scaled(s,self.min_t) end}
  local step_s = (self.max_s-self.min_s)/self.resolution_s
  for i=0,self.resolution_s do
    --local const_s = self.min_s+i*step_s
    local const_s = fiber_s.v[i]
    local fiber_t = ParametricCurve3D:new{scale=self.scale, resolution=self.resolution_t, min=self.min_t, max=self.max_t,
                                        f=function(t) return self:f_scaled(self.min_s+i*step_s,t) end}
    fiber_t:discretize()
    for j=0,self.resolution_t do
      self.xyz[i][j] = fiber_t:getNodeXYZ(j)
    end
  end
end

function ParametricSurface3D:dump()
  return dump(self.xyz)
end

function ParametricSurface3D:createMesh()
  self:discretize()
  local M = nil
  for i=0,self.resolution_s-1 do
    --local startj = 1
    --if i == 1 then startj = 2 end
    for j=0,self.resolution_t-1 do
      local Mij = create_mesh{kind="quadrilateral",vertices={self.xyz[i][j],
                                                             self.xyz[i+1][j],
                                                             self.xyz[i+1][j+1],
                                                             self.xyz[i][j+1]}}
      if M == nil then
        M = Mij
      else
        local Madd = create_mesh{ kind="add", parts={M,Mij} }
        release(M,Mn)
        M = Madd
      end
    end
  end
  if self.loop_s ~= "no" then
    for j=0,self.resolution_t-1 do
      local quad = nil
      if self.loop_s == "yes" then
        quad = {self.xyz[0][j],
                self.xyz[0][j+1],
                self.xyz[self.resolution_s][j+1],
                self.xyz[self.resolution_s][j]}
      elseif self.loop_s == "reversed" then -- (moebius strip...)
        quad = {self.xyz[0][j],
              self.xyz[0][j+1],
              self.xyz[self.resolution_s][self.resolution_t-j-1],
              self.xyz[self.resolution_s][self.resolution_t-j]}
      elseif self.loop_s == "klein" then -- (klein bottle...)
        local r = math.round(self.resolution_t/2)
        local X = (self.resolution_t-j-1+r)%self.resolution_t
        local Y = (self.resolution_t-j+r)%self.resolution_t
        quad = {self.xyz[0][j],
                self.xyz[0][j+1],
                self.xyz[self.resolution_s][X],
                self.xyz[self.resolution_s][Y]}
      end
      if quad ~= nil then
        local Mij = create_mesh{kind="quadrilateral",vertices=quad}
        local Madd = create_mesh{ kind="add", parts={M,Mij} }
        release(M,Mij)
        M = Madd
      end
    end
  end
  if self.loop_t ~= "no" then
    for i=0,self.resolution_s-1 do
      local quad = nil
      if self.loop_t == "yes" then
        quad = {self.xyz[i][0],
                self.xyz[i+1][0],
                self.xyz[i+1][self.resolution_t],
                self.xyz[i][self.resolution_t]}
      elseif self.loop_t == "reversed" then
        quad = {self.xyz[i][0],
                self.xyz[i+1][0],
                self.xyz[self.resolution_s-i-1][self.resolution_t],
                self.xyz[self.resolution_s-i][self.resolution_t]}
      end
      if quad ~= nil then
        local Mij = create_mesh{kind="quadrilateral",vertices=quad}
        local Madd = create_mesh{ kind="add", parts={M,Mij} }
        release(M,Mij)
        M = Madd
      end
    end
  end
  return M
end

-- ## --
ParametricSolid={f=nil,xyz={},
                     surface=nil,
                     resolution=20,scale=1,
                     min=0,max=1,min_t=0,max_t=1,
                     loop="no"}

function ParametricSolid:new(o)
  o = o or {}
  setmetatable(o, self)
  self.__index = self
  return o
end

-- ## --
local function _find_gravity_center(mesh)
  local center = {0,0,0}
  --[[
  local n = modalys.get_info("num-nodes",mesh)
  for i=1,n do
    for j=1,3 do center[j] = center[j]+_get_node_coordinate(mesh,i,j-1) end
  end
  for j=1,3 do center[j] = center[j]/n end
  --]]
  return center
end

local function _get_frequency_for_mesh(originalmesh, hold, freqrank, thickness, density, young, poisson, constloss, freqloss, center, scale)
  local freq = -1
  local mesh = modalys.create_mesh{mesh=originalmesh, kind="copy"}
  modalys.transform_mesh{mesh=mesh, method="homothety",center=center,scale=scale}
  _showWarning = false
  local obj = modalys.create_object{name="tmp3d",kind="finite-element",mesh=mesh,block=hold,modes=freqrank+1, thickness=thickness,
  density=density,young=young,poisson=poisson,constloss=constloss,freqloss=freqloss}
  _showWarning = true
  if obj ~= nil then
    modalys.compute_modes(obj)
    freq = modalys.get_info("mode-frequency", obj, freqrank)
  end
  modalys.release(obj,mesh)
  return freq
end

function get_pitched_finite_element_object(p)
  if p.mesh == nil or (p.midinote == nil and p.frequency == nil) then return nil end
  local obj =nil
  local mesh=p.mesh
  local name=p.name if name == nil then name = "object3D" end
  local hold=p.block
  local midinote=p.midinote
  local modes=p.modes     if modes == nil then modes=160 end
  local freqrank=p.freqrank if freqrank == nil then freqrank=1 end
  local thickness=p.thickness if thickness == nil then thickness=0.001 end
  local density=p.density   if density == nil then density=7700 end
  local young=p.young     if young == nil then young=1.95e11 end
  local poisson=p.poisson   if poisson == nil then poisson=0.2 end
  local constloss=p.constloss if constloss == nil then constloss=0.1 end
  local freqloss=p.freqloss   if freqloss == nil then freqloss=0.3 end

  local parameter=p.parameter   if parameter == nil then parameter="scale" end

  local targetfreq=p.frequency if targetfreq == nil then targetfreq = modalys.midi_to_freq(midinote) end
  local center = _find_gravity_center(mesh)
  local parammin = 1
  local parammax = 1

  local f = _get_frequency_for_mesh( mesh, hold, freqrank, thickness, density, young, poisson, constloss, freqloss, center, 1)
  if f < targetfreq then
    while f > 0 and f < targetfreq do
      parammin = parammin/4
      f = _get_frequency_for_mesh( mesh, hold, freqrank, thickness, density, young, poisson, constloss, freqloss, center, parammin)
    end
  else
    while f > targetfreq do
      parammax = parammax*4
      f = _get_frequency_for_mesh( mesh, hold, freqrank, thickness, density, young, poisson, constloss, freqloss, center, parammax)
    end
  end
  local param = math.sqrt(parammin*parammax)
  local freqmid = _get_frequency_for_mesh( mesh, hold, freqrank, thickness, density, young, poisson, constloss, freqloss, center, param)
  while math.abs(math.log(freqmid/targetfreq)) > 1e-2 do
    if freqmid < targetfreq then
      parammax = param
    else
      parammin = param
    end
    param = math.sqrt(parammin*parammax)
    freqmid = _get_frequency_for_mesh( mesh, hold, freqrank, thickness, density, young, poisson, constloss, freqloss, center, param)
  end
  modalys.print("scaling value: "..tostring(param).." for mesh "..name.." to match frequency "..tostring(targetfreq).." Hz of mode "..tostring(freqrank))
  local scaledMesh = modalys.create_mesh{kind="copy",mesh=mesh}
  modalys.transform_mesh{mesh=scaledMesh, method="homothety",center=center,scale=param}
  --modalys.save_mesh{mesh=scaledMesh,path="scaled.mesh"}
  obj = modalys.create_object{name=name,kind="finite-element",mesh=scaledMesh,block=hold,modes=modes, thickness=thickness,
  density=density,young=young,poisson=poisson,constloss=constloss,freqloss=freqloss}
  return obj
end


