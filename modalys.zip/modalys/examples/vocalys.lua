-- Modalys mlys.lua controller
-- user script
-- (psst!.. learn lua here! https://www.lua.org/manual/5.1/ )
--

-- actual user controls are: blend, gamma, noise-level, pitch-corrector-rate, pitch-corrector-period


function initialize()
	TractCalibrate = 0 -- make_controller{kind="dynamic", value=0, name="tract-calibrate"}
	
	local VocalTractVowel_A = make_object{kind="READ-FROM-FILE", path="vocalys/tract_reduced_a.modal", name="VocalTractVowel_A"}
	local Access_A1 = make_access{object=VocalTractVowel_A, location={1,0}, kind="DECODED",name="Access_A1"}
	local Access_A2 = make_access{object=VocalTractVowel_A, location={0,1}, kind="DECODED",name="Access_A2"}
			
	local VocalTractVowel_E = make_object{kind="READ-FROM-FILE", path="vocalys/tract_reduced_e.modal", name="VocalTractVowel_E"}
	local Access_E1 = make_access{object=VocalTractVowel_E, location={1,0}, kind="DECODED",name="Access_E1"}
	local Access_E2 = make_access{object=VocalTractVowel_E, location={0,1}, kind="DECODED",name="Access_E2"}
			
	local VocalTractVowel_O = make_object{kind="READ-FROM-FILE", path="vocalys/tract_reduced_o.modal", name="VocalTractVowel_O"}
	local Access_O1 = make_access{object=VocalTractVowel_O, location={1,0}, kind="DECODED",name="Access_O1"}
	local Access_O2 = make_access{object=VocalTractVowel_O, location={0,1}, kind="DECODED",name="Access_O2"}
			
	local VocalTractVowel_U = make_object{kind="READ-FROM-FILE", path="vocalys/tract_reduced_u.modal", name="VocalTractVowel_U"}
	local Access_U1 = make_access{object=VocalTractVowel_U, location={1,0}, kind="DECODED",name="Access_U1"}
	local Access_U2 = make_access{object=VocalTractVowel_U, location={0,1}, kind="DECODED",name="Access_U2"}
	
	-- # # # #			
	BlendController = make_controller{kind="dynamic", value={1,0,0,0}, name="blend"}
  Gamma = make_controller{kind="DYNAMIC", name="gamma"}
  NoiseLevel = make_controller{kind="DYNAMIC", value=0.1, name="noise-level"}
  PitchCorrectorRate = make_controller{kind="DYNAMIC", value=1.3, name="pitch-corrector-rate"}
  PitchCorrectorPeriod = make_controller{kind="DYNAMIC", value=0.02, name="pitch-corrector-period"}
	-- # # # #

	VocalTract = make_object{kind="MELT-HYBRID", name="VocalTract",
							 interpolation=BlendController,
						     objects={VocalTractVowel_A, VocalTractVowel_E, VocalTractVowel_O, VocalTractVowel_U}}
	
	AccessVocalTractInput = make_access{kind="hybrid",name="AccessVocalTractInput",object=VocalTract, accesses={Access_A1, Access_E1, Access_O1, Access_U1}}
	AccessVocalTractOutput = make_access_hybrid{object=VocalTract, accesses={Access_A2, Access_E2, Access_O2, Access_U2}}
	
	RadiatorObject = make_object{kind="RADIATOR", name="RadiatorObject", radius=0.00709175, angle=90, density=1.2, celerity=340}
	RadiatorAccess = make_access{object=RadiatorObject, location=1, name="RadiatorAccess"}
	AdhereConnection_1 = make_connection{kind="ADHERE", access1=AccessVocalTractOutput, access2=RadiatorAccess}
		
	
	ReedFrequency = make_controller{kind="dynamic", value=352.015, name="reed-freq"}
	ReedLoss = make_controller{kind="dynamic", value=30, name="reed-loss"}
	ReedAmpl = make_controller{kind="dynamic", value=2000, name="reed-ampl"}
		
	Reed = make_object{kind="single-point", name="Reed",freqs=ReedFrequency, bws=ReedLoss, amps=ReedAmpl}
	ReedAccess = make_access{object=Reed, name="ReedAccess", location=1, kind="normal"}
	ReedStaticStiffnessValue = 0 	--make_controller{kind="dynamic", value=0, name="reed-static-stiffness-value"}
  ReedAdmittanceValue = 0 			--make_controller{kind="dynamic", value=0, name="reed-admittance-value"}

	NoiseCuttoff = make_controller{kind="DYNAMIC", value=15000, name="noise-cutoff"}
	NoiseGenerator = make_controller{kind="BANDLIMITED-NOISE", cutoff=NoiseCuttoff, taps=4, name="NoiseGenerator"}
	EquilPos = 0 	--make_controller{kind="DYNAMIC", name="equilibrium-position-lg2nrmlsd"}

	AirDensity = 1.2
	FrontAngle = 180
	Zeta = 300
	Scaler = 0.0005
	FrontAreaLog2Normalized = 0 --make_controller{kind="DYNAMIC", name="front-area-lg2nrmlsd"}
	ValveApertureLengthLog2Normalized = 0 --make_controller('DYNAMIC', 1, -1, 0, 'valve-aperture-length-lg2nrmlsd')

	IndexData = make_controller{kind="CONSTANT", name="IndexData",
														  value={25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68}}

	CalibrationData = make_controller{kind="CONSTANT", name="CalibrationData", value={inf,24.5906,25.129,25.027,20.6924,26.0922,26.1074,26.0335,21.8613,27.2105,27.1106,26.5011,28.1406,28.2235,27.621,27.0447,29.1441,29.2391,28.1551,27.6918,30.4271,29.9005,28.7905,28.3945,31.0459,30.3352,29.4847,29.1337,32.4849,31.0091,30.2261,29.9066,33.4973,31.7384,30.992,30.7068,34.5425,32.5148,31.7862,31.521,35.4357,33.3178,32.6022,32.3442,35.5853,34.1463,33.4378,33.1769,36.3454,34.997,34.2883,34.0159,37.1653,35.866,35.1547,34.8614,38.0198,36.7527,36.0348,35.7078,38.8973,37.6561,36.9275,36.5386,39.7894,38.5721,37.8403,37.3894,40.7059,39.5112,38.7643,38.2691,41.6347,40.4636,39.6976,39.134,42.5792,41.4221,40.6476,40.05,43.5488,42.4057,41.6042,40.9867,44.5083,43.3623,42.5371,41.8935,45.5227,44.3818,43.4325,42.7902,46.5141,45.3422,44.3437,43.6775,47.533,46.2391,45.2162,44.5439,48.6315,47.2966,46.161,45.368,49.5716,48.0907,46.9542,46.2145,50.7345,49.1662,47.931,46.9633,51.8474,50.2789,48.8917,47.7498,52.7816,50.9653,49.5685,48.4681,54.0477,52.2102,50.7764,49.2726,55.4268,53.7837,52.1454,50.0774,56.2531,54.2932,52.7388,50.7093,57.3065,55.3553,53.8339,52.0461,58.9532,57.1369,55.72,54.015,60.1877,58.9646,57.5232,55.53,61.1371,59.3948,57.9425,56.4556,62.355,60.5035,59.1449,57.894,63.9723,62.1826,60.8057,59.8067,65.6485,64.5435,63.4082,62.2446,65.9933,65.8598,64.9742,64.1124,67.4276,66.3578,65.2705,64.2534,68.8916,67.9619,66.9383,65.9379,inf,69.6016,68.6814,67.7141}}
	add_controller_dependency(BlendController)
	print("Vocalys is ready!")
	ExprGetReedStaticStiffness()
end

function ExprGetFrontArea()
	local k_r = ExprGetReedStaticStiffness();
	local Zc = ExprGetVocalTractInputAdmittance();
	local y_0 = ExprGetExp2EquilPosByFactor();
	local w = ExprGetApertureLength();
	local z = Zeta/(Zc*w)
	return ExprGetFrontAreaNormalized()*Scaler*.5*AirDensity*(k_r/y_0)*z*z
end

function ExprGetVocalTractInputAdmittance()
	return get_info("admittance", AccessVocalTractInput)
end

function ExprGetApertureLength()
	local a = 0.0223607
	return a*ExprGetValveApertureLengthNormalized()
end

function ExprGetValveApertureLengthNormalized()
	return 2^ValveApertureLengthLog2Normalized
end

function ExprGetFrontAreaNormalized()
	return 2^FrontAreaLog2Normalized
end

function ExprUpdateReedAccessPositionOffset()
	-- depends on: ExprGetExp2EquilPosByFactor
	set_info("access-position-offset",ReedAccess,ExprGetExp2EquilPosByFactor())
end

function ExprGetExp2EquilPosByFactor()
	-- depends on: ExprGetExp2EquilPos
	local factor = 0.005
	return ExprGetExp2EquilPos()*factor
end

function ExprGetExp2EquilPos()
	-- depends on: EquilPos
	-- update = -1
	return 2^EquilPos
end

function ExprGetReedStaticStiffness()
	-- depends on: ReedAccess, ReedStaticStiffnessValue, ReedFrequency
	-- update = -1
	local v = get_info("static-stiffness",ReedAccess)
	ReedStaticStiffnessValue = v --set_value(ReedStaticStiffnessValue,v)
	return v
end

function ExprUpdateReedAdmittance()
	-- depends on: ReedAccess, ReedAdmittanceValue, ReedFrequency
	-- update = -1
	local v = get_info("admittance",ReedAccess)
	ReedAdmittanceValue = v --set_value(ReedAdmittanceValue,v)
	return v
end

function update()
	--return ExprGetFrontArea()
end