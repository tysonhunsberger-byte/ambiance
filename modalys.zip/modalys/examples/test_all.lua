-- mlys.lua script that verifies all functions!
--
require("tools")

local check = function(o,f,t)
	if o == nil then
		if t == nil then t = "" end
		print("✘ !! "..t.." ("..f..")")
	else
		if t == nil then t = "" end
		print("✓ "..t.." ("..f..")")
	end
	return o
end

local expected_equal = function(o1,o2)
	if _isController(o1) then
		local equal = true
		local v = get_value(o1)
		if type(v) == "number" then
			v = {v}
			o2 = {o2}
		end
		if #v == #o2 then
			for n=1,#v do
				if math.abs(v[n]-o2[n])>0.00001 then
					print(v[n].."  "..o2[n])
					equal = false
					break
				end
			end
		end
		if equal then
			print("✓ ".._get_variable_name(o1).." = "..dump(o2))
		else
			print("✘ !! ".._get_variable_name(o1).." ≠ "..dump(o2))
		end
	elseif type(o1) == "number" and type(o2) == "number" then
		if math.abs(o1-o2)<0.00001 then
			print("✓ "..o1.." = "..o2)
			return true
		else
			print("✘ !! "..o1.." ≠ "..o2)
			return false
		end
	end
	return false
end

local get_shared_folder = function()
	-- taking platform into account:
    local path = "c:\\Users\\Public\\";
	if get_os() == "mac" then
    	path = "/Users/Shared/";
	end
	return path
end

function initialize()
	
	--local stuff = dump(modalys)
	--local f = io.open("/Users/Shared/modalys_dump.txt", "w")
	--f:write(stuff)
	--f:close()
	
	-- REF of classic mlys objects:
	local mlysStringRef = check(get_ref("myMlysString"), "get_ref")
	
	-- OBJECTS:
	local sp = 		check(create_object{ kind="single-point",name="sp" },"create_object","single-point")
	local ho1 = 	check(create_object{ kind="harmonic-oscillator",name="ho1" },"create_object","harmonic-oscillator")
	local m1 = 		check(create_object{ kind="mono-two-mass",name="m1" },"create_object","mono-two-mass")
	local m2 = 		check(create_object{ kind="bi-two-mass",name="m2" },"create_object","bi-two-mass")
	local s1 = 		check(create_object{ kind="mono-string",name="s1" },"create_object","mono-string")
	local s2 = 		check(create_object{ kind="bi-string",name="s2" },"create_object","bi-string")
	--local hc = 		check(create_object{ kind="hanging-chain",name="hc" },"create_object","hanging-chain")
	local cl = 		check(create_object{ kind="clone",name="cl",original=s1 },"create_object","clone")
	local br1 = 	check(create_object{ kind="violin-bridge",name="b1" },"create_object","violin-bridge")
	local br2 = 	check(create_object{ kind="cello-bridge",name="b2" },"create_object","cello-bridge")
	local m3 = 		check(create_object{ kind="circ-membrane",name="m3" },"create_object","circ-membrane")
	local m4 = 		check(create_object{ kind="rect-membrane",name="m4" },"create_object","rect-membrane")
	local bar1 =	check(create_object{ kind="rect-free-bar",name="b3" },"create_object","rect-free-bar")
	local p1 = 		check(create_object{ kind="rect-plate",name="p1" },"create_object","rect-plate")
	local p2 = 		check(create_object{ kind="clamped-circ-plate",name="p2" },"create_object","clamped-circ-plate")
	local p3 = 		check(create_object{ kind="free-circ-plate",name="p3" },"create_object","free-circ-plate")
	local t1 = 		check(create_object{ kind="closed-closed-tube",name="t1" },"create_object","closed-closed-tube")
	local t2 = 		check(create_object{ kind="closed-open-tube",name="t2" },"create_object","closed-open-tube")
	local t3 = 		check(create_object{ kind="open-open-tube",name="t3" },"create_object","open-open-tube")
	local rad1 = 	check(create_object{ kind="radiator",name="r1" },"create_object","radiator")
	local j1 = 		check(create_object{ kind="jet",name="j1" },"create_object","jet")
	
	local melthybr = check(make_object{kind="MELT-HYBRID", name="MeltHybrid", interpolation={0.3,0.5,0,0.8}, objects={s1,s2,m3,m4}},"create_object","melt-hybrid")
	local mixhybr = check(make_object{kind="MIX-HYBRID", name="MixHybrid", interpolation=0.5, object1=m3, object2=m4},"create_object","mix-hybrid")
	local trihybr = check(make_object{kind="TRI-HYBRID", name="TriHybrid", interpolation={0.9,0.1,0.3}, object1=p1, object2=p2, object3=p3},"create_object","tri-hybrid")
	
	-- mesh and finite elements...
	local mesh1 = 	check(create_mesh{ kind="single-point", position={0,0.1,0} }, "create_mesh", "single-point")
	local quad1 = 	check(create_mesh{ kind="quadrilateral", vertices={{0.3,0.2,0.1},{1,-0.1,1},{1.2,0,-0.99},{0,1,2}} }, "create_mesh", "quadrilateral")
	mesh1 = 		check(extend_mesh{ method="translation",mesh=mesh1,steps=1,vector={0,0.05,0}}, "extend_mesh", "translation")
	mesh1 = 		check(extend_mesh{ method="rotation",mesh=mesh1,steps=7,axis={1,0,0},center={0,0,0},angle=10 }, "extend_mesh", "rotation")
	--TODO: test all mesh transformations
	save_mesh{mesh=mesh1,path=get_shared_folder().."test.mesh"}
	--view_mesh(mesh1)
	local fem = check(create_object{ kind="finite-element",name="fem1",mesh=mesh1 },"create_object","finite-element")
	--TODO: add hold, compute modes, view mode
	--local mp = check(create_object{ kind="multiple-point",name="mp" },"create_object","multiple-point")
	--TODO: HYBRIDS
	
	-- ACCESS / INPUT-OUTPUT:
	--trans1,long,normal,top-vertical,top-horizontal,base,decoded,xyz,point-at-quad,basic,foot,flue-exit,labium
	--NB: access kind is deduced from object type in most situations
	local spAccess =	check(create_access{where=sp,name="singlePointAccess"},"create_access")
	local ho1acc = 		check(create_access{where=ho1,name="harmOscAccess1",position=0.},"create_access")
	local m1acc1 = 		check(create_access{where=m1,name="mono2massAccess1",position=0.},"create_access")
	local m1acc2 = 		create_access{where=m1,name="mono2massAccess2",position=1.}
	local m2acc1 = 		create_access{where=m2,kind="trans0",name="bi2massAccess1",position=0.}
	local m2acc2 = 		create_access{where=m2,kind="trans1",name="bi2massAccess2",position=1.}
	local s1acc1 = 		create_access{where=s1,name="string1Access1",position=0.35}
	local s1acc2 = 		create_access{where=s1,name="string1Access2",position=0.21}
	local s1acc3 = 		create_access{where=s1,name="string1Access3",position=0.63}
	local s1acc4 = 		create_access{where=s1,name="string1Access4",position=0.17}
	local s1acc5 = 		create_access{where=s1,name="string1Access5",position=0.84}
	local s2acc1 = 		check(create_access{where=s2,kind="trans0",name="string2Access1",position=0.34},"create_access","trans0")
	local s2acc2 = 		check(create_access{where=s2,kind="trans1",name="string2Access2",position=0.48},"create_access","trans1")
	local vbacc1 = 		check(create_access{where=br1,name="violinBridgeAccess1",position=1},"create_access")
	local vbacc2 = 		check(create_access{where=br1,name="violinBridgeAccess2",position=-1},"create_access")
	local vbacc3 = 		check(create_access{where=br1,kind="top-horizontal",name="violinBridgeAccess3",position=0.03},"create_access")
	local vbacc4 = 		check(create_access{where=br1,kind="top-vertical",name="violinBridgeAccess4",position=0.015},"create_access")
	local cbacc1 = 		check(create_access{where=br2,name="celloBridgeAccess1",position=1},"create_access")
	local cbacc2 = 		check(create_access{where=br2,name="celloBridgeAccess2",position=-1},"create_access")
	local cbacc3 = 		check(create_access{where=br2,kind="top-horizontal",name="celloBridgeAccess3",position=0.03},"create_access")
	local cbacc4 = 		check(create_access{where=br2,kind="top-vertical",name="celloBridgeAccess4",position=0.015},"create_access")
	local t1acc = 		check(create_access{where=t1,name="Tube1Access1",position=0.2},"create_access")
	local t2acc = 		check(create_access{where=t2,name="Tube2Access1",position=0.25},"create_access")
	local t3acc = 		check(create_access{where=t3,name="Tube3Access1",position=0.19},"create_access")
	local t3acc2 = 		check(create_access{where=t3,name="Tube3Access2",position=0.01},"create_access")
	local p3acc = 		check(create_access{where=p3,name="circPlateAccess1",position={0.25,45}},"create_access")
	local rad1access = 	check(create_access{where=rad1,name="radiatorAccess1"},"create_access")
	
			
	-- INPUT/OUTPUT
	local ptinput1 = check(create_point_input{ name="ptinput1",channel=1,gain=0.9 },"create_point_input")
	local ptinput2 = check(create_point_input{ name="ptinput2",channel=2,gain=0.4 },"create_point_input")
	check(create_point_output{ where=s1acc4,name="ptoutput1",channel=1,gain=1.2 },"create_point_output")
	check(create_point_output{ where=s1acc5,name="ptoutput2",channel=2,gain=1 },"create_point_output")
		
		
	-- CONTROLLERS
	local ctldyn1 = check(create_controller{kind="constant",value={0.1,1.4,1.3e-8}},"create_controller", "constant")
	local ctldyn1 = check(create_controller{kind="dynamic",value={0.1,1.4,1.3e-8},name="MyDynamic1"},"create_controller", "dynamic (multidim)")
	local ctlsig1 = check(create_controller{kind="signal",input=ptinput1,name="MySignal1"},"create_controller", "signal")
	local ctlsig2 = check(create_controller{kind="signal",inputs={ptinput1,ptinput2},name="MySignal2"},"create_controller", "signal")
	local ctlspeed = check(create_controller{kind="access-speed",access=s1acc2,name="MyAccessSpeedCtl"},"create_controller", "access-speed")
	local ctlpos   = check(create_controller{kind="access-position",access=s1acc2,name="MyAccessPosCtl"},"create_controller", "access-position")
		
	local ctlfreqs  = create_controller{kind="dynamic",value={440,334,2345},name="MyFrequencies"}
	local freqValues1 = get_info("value", ctlfreqs)
	expected_equal(ctlfreqs,{440,334,2345})
	local ctlphases = create_controller{kind="dynamic",value={0.,0.1,0.2},name="MyPhases"}
	local ctlsine   = check(create_controller{kind="sine",freqs=ctlfreqs, phases=ctlphases,name="MySine1"},"create_controller", "sine (multidim)")
	local ctlsine2  = check(create_controller{kind="sine",freq=440,phase=0.01,name="MySine2"},"create_controller", "sine")
	local ctlrand   = check(create_controller{kind="random",dim=3,period=0.005,name="MyRandom"},"create_controller", "random")
	local ctlphase  = check(create_controller{kind="phasor",freqs=ctlfreqs,phases=ctlphases,name="MyPhasor1"},"create_controller", "phasor")
	local ctlphase2  = check(create_controller{kind="phasor",freq=440,phase=0.03,name="MyPhasor2"},"create_controller", "phasor")
		
	local ctli1 = create_controller{kind="constant",value={4.5, -2.1}}
	local ctli2 = create_controller{kind="constant",value={3.2, -45.9}}
	local ctlAr1 = create_controller{kind="arithmetic",name="ArithmeticMult",operator="*",input={ctli1,ctli2}}
	expected_equal(ctlAr1,{14.4,96.39})


		
	local ctrlscale1 = check(create_controller{kind="scale",input=ctlsine2, name="MyScale1"},"create_controller", "scale")

	local ctlnoise1  = check(create_controller{kind="noise",dimension=1,period=0,cutoff=8000,delmin=0.3,delmax=0.7,outmin=0,outmax=1,taps=30, name="MyNoise1"},"create_controller", "noise")
	local ctlnoise2  = check(create_controller{kind="noise",dimension=2,period=0,cutoff={2200,8000},delmin={0.3,0.2},delmax={0.7,0.9},outmin={0,-0.5},outmax={1,2.5},taps=30, name="MyNoise2"},"create_controller", "noise (multidim)")
	local ctlnoise3  = check(create_controller{kind="noise",dimension=4,period=0,taps=30, name="MyNoise3"},"create_controller", "noise (multidim without default values)")
	local ctlCutoff = create_controller{kind="dynamic",value=8000,name="MyCtlCutoff"}
	local ctlbandlimitednoise  = check(create_controller{kind="bandlimited-noise",period=0,cutoff={220,440,880},taps=30, name="MyBandLimitedNoise"},"create_controller", "bandlimited-noise")
	

	local ctrlinput = create_controller{kind="dynamic",value={0,1,2,3},name="InputCtrl"}
	local ctrlbilinearfilter = check(create_controller{kind="bilinear-filter",coefficients={2.3,0,1.5},input=ctrlinput, name="MyBilinearFilter"},"create_controller", "bilinear-filter")
			
	local ctrlinput2 = create_controller{kind="dynamic",value={0,1,2,3,5,6,7,8},name="InputCtrl2"}
	local ctrlbiquadraticfilter = create_controller{kind="biquadratic-filter",coefficients={2.3,0,1.5,4.3,-1.08},input=ctrlinput2, name="MyQuadraticFilter"}

	local ctrlrandom2  = create_controller{kind="random", dim=2, name="Random2"}
	local ctrlrandom3  = create_controller{kind="random", dim=1, name="Random3"}
	local ctrlconst2ndorder1 = check(create_controller{kind="constant-second-order-filter",
																									period=-1,
																									input=ctrlrandom3,
																								  amps=1,
																								  freqs=220,
																								  bandwidths=10,
																									name="MyConstant2ndOrderFilter"},"create_controller", "constant-second-order-filter (dim 1)")
	local ctrlconst2ndorder2 = check(create_controller{kind="constant-second-order-filter",
																									period=-1,
																									input=ctrlrandom2,
																								  amps={1,2},
																								  freqs={220,393},
																								  bandwidths={10,15},
																									name="MyConstant2ndOrderFilter"},"create_controller", "constant-second-order-filter (dim 2)")

	local ctrlvar2ndorder = check(create_controller{kind="variable-second-order-filter",
																									period=-1,
																									input=ctrlrandom3,
																								  freq=700,
																								  bandwidth=20,
																									name="Variable2ndOrderFilter"},"create_controller", "variable-second-order-filter")

			
			
	local input1 = create_controller{kind="dynamic",value={0,1,2,3.2,5,6,7,8},name="input1"}
	local input2 = create_controller{kind="dynamic",value={3,5,6,7,8},name="input2"}
	local input3 = create_controller{kind="dynamic",value={6,7,8,9},name="input3"}
	local mapping = {{input1,3,0,1,2},{input2,1,3},{input3,2,4,5}}
	local ctrlmapping   = check(create_controller{kind="dimension-mapping",name="MyDimensionMapping", dimension=6, input=mapping},"create_controller", "dimension-mapping")
	expected_equal(ctrlmapping,{3.2,3.2,3.2,5,8,8})

	local dimCtrl1 = check(create_controller{kind="dimension",input=input3,rank=0},"create_controller", "dimension")
	expected_equal(dimCtrl1,6)
	local dimCtrl2 = check(create_controller{kind="dimension",input=input3,rank=1},"create_controller", "dimension")
	expected_equal(dimCtrl2,7)

	local ctrlSum = check(create_controller{kind="sum",input=input1,period=0.01},"create_controller", "sum")
	expected_equal(ctrlSum,32.2)

	local ctrldelay = check(create_controller{kind="delay",input=ctrlbiquadraticfilter,delay=0.6,name="DelayCtrl"},"create_controller", "delay")


	-- CONNECTIONS:
	local cxf1 = 		check(create_connection{kind="force",where=s1acc1,name="cxForce1",weight=0.3},"create_connection", "force")
	--- force connexion with a signal ctrl as input:
	local cxf2 = 		check(create_connection{kind="force",where=s1acc2,name="cxForce2",input=ctlsig1,weight=0.3},"create_connection", "force-signal")
	local ctlaccforce = check(create_controller{kind="access-force",name="ctlaccforce2",access=s1acc1},"create_controller", "access-force")
	local cxsp = 		create_connection{kind="speed",where=s1acc2,name="cxSpeed1"}
	local cxpos = 		create_connection{kind="position",where=m1acc1,name="cxPosition1",weight=1.}
	local cxstrke = 	create_connection{kind="strike",where1=s2acc1,where2=m1acc2,name="cxStrike1",weight=0.8}
	local cxstrkeUni = 	create_connection{kind="strike",where=s2acc2,name="cxStrike2",weight=0.5}
	local cxadhere = 	check(create_connection{kind="adhere",where1=s1acc1,where2=s2acc1,name="cxAdhere",weight=0.7},"create connection", "adhere")
	local cxadhere = 	check(create_connection{kind="adhere",where=s1acc1,name="cxAdhereUnilateral",weight=0.3},"create connection", "adhere (unilateral)")
	local cxpluck = 	create_connection{kind="pluck",where1=s1acc1,where2=m1acc2,name="cxPluck",breakingforce=100,weight=0.7}
	local cxsprin = 	create_connection{kind="spring",where1=s1acc1,where2=s2acc1,name="cxSpring",stiffness=10000,weight=0.9}
	local cxbow = 		create_connection{kind="bow",name="cxBow",bowVaccess=m2acc1,bowHaccess=m2acc2,bowInitialVposition=0.1,
												  objectVaccess=s2acc1,objectHaccess=s2acc2,objectInitialVposition=0,rosin={2,10,5,4}}
	local cxfelt = 		create_connection{kind="felt",name="cxFelt",where1=s2acc1,initialposition1=0,where2=m1acc2,initialposition2=0.1,
												  thickness=0.01,f0=1000,alpha=2.5,epsilon=0.55,tau=1e-7}								
	local cxhole = 		check(create_connection{kind="hole",where=t3acc,name="cxHole1",radius=0.01,noise=0.1,weight=0.8},"create connection", "hole")
	local cxviscousdamp = check(create_connection{kind="viscous-damping",where=t3acc2,name="cxViscousDamp",coeff=0.4,weight=0.9},"create connection", "viscous damping")
	local cxReed = 		create_connection{kind="reed",reedaccess=m1acc1,tubeaccess=t3acc2,name="cxReed",initialposition=0.01,
												  airpressure=2e4,airdensity=1.2,readarea=1e-8,aperturelength=2.76e-4,weight=0.7}
												
	local cxNormalisedValve = create_connection{kind="normalised-valve", name="MyNormalisedValve",
																							valveaccess=m1acc1, initialposition=0.001, objectaccess=t3acc,
                                  						breath=0, airdensity=1.2, zeta=0.7, frontangle=1e-8, aperturelength=0.01, weight=1}

	local cxNormalizedLeakyValve = 	create_connection{kind="normalised-leaky-valve", name="MyNormalisedLeakyValve",
															  										valveaccess=m1acc1, initialposition=0.001, objectaccess=t3acc,
                                   							  	breath=0, airdensity=1.2, airviscosity=1.78e-5,
															  										zeta=0.7, frontangle=1e-8, aperturewidth=0.001, canallength=0.01, underarea=1.8e-5, weight=1}

	local cxLeakyValve1 = 	check(create_connection{kind="leaky-valve",name="cxLeakyValve1",
																									valveaccess=m1acc1,
																									objectaccess=t3acc}, "create_connection", "leaky-valve (1 access)")
	local cxLeakyValve2 = 	check(create_connection{kind="leaky-valve",name="cxLeakyValve2",
																									valveaccess1=m1acc1,valveaccess1=m1acc2,
																									objectaccess=t3acc}, "create_connection", "leaky-valve (2 accesses)")	
	local cxLabium = 	check(create_connection{kind="labium", name="cxLabium",
																						where=t3acc,
																						jet=j1}, "create_connection", "labium")
	
	local cxValve1 = 	check(create_connection{kind="valve",name="cxValve1",
																						valveaccess=m1acc1, initialposition=0.002,
																					  objectaccess=t3acc}, "create_connection", "valve")
	local cxValve2 = 	check(create_connection{kind="valve",name="cxValve2",
																						valveaccess1=m1acc1, initialposition1=0.001,
																						valveaccess2=m1acc2, initialposition2=0.034,
																					  objectaccess=t3acc}, "create_connection", "valve")
	-- TODO
	local cxMonoFingerboard = 	check(create_connection{ kind="mono-fingerboard",
																											 fingeraccess=ho1acc,
																											 stringaccess=s1acc1,
																											 initialfingerposition=0.02,
																											 initialstringposition=0.01,
																											 fingerboardposition=0,
																											 name="cxMonoFingerboard"}, "create_connection", "mono-fingerboard")
	local cxBiFingerboard = 	check(create_connection{ kind="bi-fingerboard",
																										 fingervaccess=m2acc1, fingerhaccess=m2acc2,
																										 stringvaccess=s2acc1, stringhaccess=s2acc2,
																										 initialfingerposition=0.02,
																										 initialstringposition=0.01,
																										 fingerboardposition=0.03,
																										 name="cxBiFingerboard"}, "create_connection", "bi-fingerboard")
	local cxInduction = 	check(create_connection{ kind="induction",
																								 stringaccess=s1acc1,
																								 magnetaccess=m1acc1,
																								 signal=ctlsine2,
																								 name="cxInduction"}, "create_connection", "induction")

	local lastSampleCtrl = check(create_controller{kind="last-sample"},"create_controller", "last-sample")

	-- GETINFO
	-- TODO
	
	-- SETINFO
	-- TODO
	post_thru_modalys_tilde("truc#1", "truc#2", 440)
	print("sample rate: "..get_info("sample-rate"))
	print("sample rate: "..get_sample_rate())
		
	print("mlys.lua - end of test!")
end

function update()
	local ctrl = inlet(1)
	return 0.1, 0.2, 0.3
end